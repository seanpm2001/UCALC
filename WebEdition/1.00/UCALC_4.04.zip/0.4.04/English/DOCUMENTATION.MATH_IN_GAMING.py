WikIDSelect = int(10009)
if WikIDSelect == 10009:
	if WikIDSelect == 10009:
		if WikIDSelect == 10009:
			if WikIDSelect == 10009:
				print ("Math in gaming")
				print ("\n\n")
				tf2qu1 = input("Press [ENTER] key to read about the math of Team Fortress 2")
				print ("\nHeavy - Team Fortress 2")
				print ("I am Heavy Weapons Guy...and this is my weapon.") 
				print ("She weighs one hundred fifty kilograms and fires")
				print ("two hundred dollar, custom-tooled cartridges at ten")
				print ("thousand rounds per minute. It costs four hundred ")
				print ("thousand dollars to fire this weapon...for twelve seconds")
				print ("\t\t\t\t\tFrom 'Meet the heavy' by Valve")
				print ("OK, let's analyze this. ") # sean was too busy with other things to analyze this on 11/21/2018