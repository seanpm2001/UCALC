WikIDSelect = int(30006)
if WikIDSelect == 30006:
	if WikIDSelect == 30006:
		if WikIDSelect == 30006:
			if WikIDSelect == 30006:
				print ("Multiples table")
				print ("\n")
				print ("| 0  |  1  |  2  |")
				print ("| 1  |  1  |  2  |")
				print ("| 2  |  2  |  3  |")
noMore = input("Press [ENTER] key to exit")