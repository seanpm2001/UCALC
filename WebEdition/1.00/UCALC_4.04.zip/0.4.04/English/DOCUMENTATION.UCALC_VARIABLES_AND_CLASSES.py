WikIDSelect = int(20019)
if WikIDSelect == 20019:
	if WikIDSelect == 20019:
		if WikIDSelect == 20019:
			if WikIDSelect == 20019:
				print ("Variables in the UCALC source code")
				print ("\n")
				print ("noMore   - this is an overwrite variable meant to hold back text from just flooding down too fast. It just requires enter to be pressed, and is there to tell you that this is the end of an article, mode, or feature")
				print ("more1    - this is an overwrite variable that divides articles into section, and must be bypassed to continue. Bypass by pressing the [ENTER] key")
				print ("calcIDSes - this is an integer that takes you to different modes on a calculator")
				print ("WikIDSelect - this is an integer that accepts the input to go into different articles")
				print ("konloop - this is a loop function that loops output")
				print ("modID - this is a string that prints out the calculator hardware model")
				print ("conloop - this is another loop function that loops output")
				print (" ")
				noMore = input("Press [ENTER] key to exit")