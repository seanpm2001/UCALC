print (" ")
print (" ")
print (" ____  __    ___  ____  _____  ____                              ")
print ("( ___)/__\\  / __)(_  _)(  _  )(  _ \\                             ")
print (" )__)/(__)\\( (__   )(   )(_)(  )   /                             ")
print ("(__)(__)(__)\\___) (__) (_____)(_)\\_)                             ")
print ("  ___    __    __    ___  __  __  __      __   ____  _____  ____ ")
print (" / __)  /__\\  (  )  / __)(  )(  )(  )    /__\\ (_  _)(  _  )(  _ \\")
print ("( (__  /(__)\\  )(__( (__  )(__)(  )(__  /(__)\\  )(   )(_)(  )   /")
print (" \\___)(__)(__)(____)\\___)(______)(____)(__)(__)(__) (_____)(_)\\_)")
print (" ")
enterToEnter = input("Press [ENTER] key to start! ")
calcIDSes = int(68)
if calcIDSes == 68:
	factorFindEnter = int(input("Enter a number to find its factors (NO DECIMALS): "))
	if factorFindEnter == 0:
		print ("0 has no factors other than itself")
	if factorFindEnter == 1:
		print ("1 has no factors other than itself")
	else:
		print ("Error! This feature is incomplete and the calculation didn't go through")
noMore = input("Press [ENTER] key to quit")