print ("Character sheet")
print ("\n\n\n")
loopforever = int(1)
while (loopforever == 1):
	print ("Select a category")
	print ("ANSI | ")
	print ("Bullets |")
	print ("Chess & checkers |")
	print ("Currency |")
	print ("DOS |")
	print ("Faces |")
	print ("Identification |")
	print (" ")
	print ("Musical notes |")
	print ("Punctuation |")
	print ("Religeon |")
	categoryStrEnter = str(input("Type in an ID to start: "))
	if (categoryStrEnter == "ANSI" or categoryStrEnter == "Ansi" or categoryStrEnter == "ansi"):
		print ("ANSI Character sheet - UCALC Char sheet")
		print ("\n")
		print ("|=======================================================================================================================|")
		print ("| a | AN001 | b | AN002 | c | AN003 | d | AN004 | e | AN005 | f | AN006 | g | AN007 | h | AN008 | i | AN009 | j | AN010 |")
		print ("| k | AN011 | l | AN012 | m | AN013 | n | AN014 | o | AN015 | p | AN016 | q | AN017 | r | AN018 | s | AN019 | t | AN020 |")
		print ("| u | AN021 | v | AN022 | w | AN023 | x | AN024 | y | AN025 | z | AN026 | A | AN027 | B | AN028 | C | AN029 | D | AN030 |")
		print ("| E | AN031 | F | AN032 | G | AN033 | H | AN034 | I | AN035 | J | AN036 | K | AN037 | L | AN038 | M | AN039 | N | AN040 |")
		print ("| O | AN041 | P | AN042 | Q | AN043 | R | AN044 | S | AN045 | T | AN046 | U | AN047 | V | AN048 | W | AN049 | X | AN050 |")
		print ("| Y | AN051 | Z | AN052 |===============================================================================================|")
		print ("|=======================|")
		enterAnID = str(input("Enter an ID to continue: "))
		if (enterAnID == "an001" or enterAnID == "An001" or enterAnID == "AN001"):
			print ("AN001 |       a")
		if (enterAnID == "an002" or enterAnID == "An002" or enterAnID == "AN002"):
			print ("AN002 |       b")
		if (enterAnID == "an003" or enterAnID == "An003" or enterAnID == "AN003"):
			print ("AN003 |       c")
		if (enterAnID == "an004" or enterAnID == "An004" or enterAnID == "AN004"):
			print ("AN004 |       d")
		if (enterAnID == "an005" or enterAnID == "An005" or enterAnID == "AN005"):
			print ("AN005 |       e")
		if (enterAnID == "an006" or enterAnID == "An006" or enterAnID == "AN006"):
			print ("AN006 |       f")
		if (enterAnID == "an007" or enterAnID == "An007" or enterAnID == "AN007"):
			print ("AN007 |       g")
		if (enterAnID == "an008" or enterAnID == "An008" or enterAnID == "AN008"):
			print ("AN008 |       h")
		if (enterAnID == "an009" or enterAnID == "An009" or enterAnID == "AN009"):
			print ("AN009 |       i")
		if (enterAnID == "an010" or enterAnID == "An010" or enterAnID == "AN010"):
			print ("AN010 |       j")
		if (enterAnID == "an011" or enterAnID == "An011" or enterAnID == "AN011"):
			print ("AN011 |       k")
		if (enterAnID == "an012" or enterAnID == "An012" or enterAnID == "AN012"):
			print ("AN012 |       l")
		if (enterAnID == "an013" or enterAnID == "An013" or enterAnID == "AN013"):
			print ("AN013 |       m")
		if (enterAnID == "an014" or enterAnID == "An014" or enterAnID == "AN014"):
			print ("AN014 |       n")
		if (enterAnID == "an015" or enterAnID == "An015" or enterAnID == "AN015"):
			print ("AN015 |       o")
		if (enterAnID == "an016" or enterAnID == "An016" or enterAnID == "AN016"):
			print ("AN016 |       p")
		if (enterAnID == "an017" or enterAnID == "An017" or enterAnID == "AN017"):
			print ("AN017 |       q")
		if (enterAnID == "an018" or enterAnID == "An018" or enterAnID == "AN018"):
			print ("AN018 |       r")
		if (enterAnID == "an019" or enterAnID == "An019" or enterAnID == "AN019"):
			print ("AN019 |       s")
		if (enterAnID == "an020" or enterAnID == "An020" or enterAnID == "AN020"):
			print ("AN020 |       t")
		if (enterAnID == "an021" or enterAnID == "An021" or enterAnID == "AN021"):
			print ("AN021 |       u")
		if (enterAnID == "an022" or enterAnID == "An022" or enterAnID == "AN022"):
			print ("AN022 |       v")
		if (enterAnID == "an023" or enterAnID == "An023" or enterAnID == "AN023"):
			print ("AN023 |       w")
		if (enterAnID == "an024" or enterAnID == "An024" or enterAnID == "AN024"):
			print ("AN024 |       x")
		if (enterAnID == "an025" or enterAnID == "An025" or enterAnID == "AN025"):
			print ("AN025 |       y")
		if (enterAnID == "an026" or enterAnID == "An026" or enterAnID == "AN026"):
			print ("AN006 |       z")
		if (enterAnID == "an027" or enterAnID == "An027" or enterAnID == "AN027"):
			print ("AN027 |       A")
		if (enterAnID == "an028" or enterAnID == "An028" or enterAnID == "AN028"):
			print ("AN028 |       B")
		if (enterAnID == "an029" or enterAnID == "An029" or enterAnID == "AN029"):
			print ("AN029 |       C")
		if (enterAnID == "an030" or enterAnID == "An030" or enterAnID == "AN030"):
			print ("AN030 |       D")
		if (enterAnID == "an031" or enterAnID == "An031" or enterAnID == "AN031"):
			print ("AN031 |       E")
		if (enterAnID == "an032" or enterAnID == "An032" or enterAnID == "AN032"):
			print ("AN032 |       F")
		if (enterAnID == "an033" or enterAnID == "An033" or enterAnID == "AN033"):
			print ("AN033 |       G")
		if (enterAnID == "an034" or enterAnID == "An034" or enterAnID == "AN034"):
			print ("AN034 |       H")
		if (enterAnID == "an035" or enterAnID == "An035" or enterAnID == "AN035"):
			print ("AN035 |       I")
		if (enterAnID == "an036" or enterAnID == "An036" or enterAnID == "AN036"):
			print ("AN036 |       J")
		if (enterAnID == "an037" or enterAnID == "An037" or enterAnID == "AN037"):
			print ("AN037 |       K")
		if (enterAnID == "an038" or enterAnID == "An038" or enterAnID == "AN038"):
			print ("AN038 |       L")
		if (enterAnID == "an039" or enterAnID == "An039" or enterAnID == "AN039"):
			print ("AN039 |       M")
		if (enterAnID == "an040" or enterAnID == "An040" or enterAnID == "AN040"):
			print ("AN040 |       N")
		if (enterAnID == "an041" or enterAnID == "An041" or enterAnID == "AN041"):
			print ("AN041 |       O")
		if (enterAnID == "an042" or enterAnID == "An042" or enterAnID == "AN042"):
			print ("AN042 |       P")
		if (enterAnID == "an043" or enterAnID == "An043" or enterAnID == "AN043"):
			print ("AN043 |       Q")
		if (enterAnID == "an044" or enterAnID == "An044" or enterAnID == "AN044"):
			print ("AN044 |       R")
		if (enterAnID == "an045" or enterAnID == "An045" or enterAnID == "AN045"):
			print ("AN045 |       S")
		if (enterAnID == "an046" or enterAnID == "An046" or enterAnID == "AN046"):
			print ("AN046 |       T")
		if (enterAnID == "an047" or enterAnID == "An047" or enterAnID == "AN047"):
			print ("AN047 |       U")
		if (enterAnID == "an048" or enterAnID == "An048" or enterAnID == "AN048"):
			print ("AN048 |       V")
		if (enterAnID == "an049" or enterAnID == "An049" or enterAnID == "AN049"):
			print ("AN049 |       W")
		if (enterAnID == "an050" or enterAnID == "An050" or enterAnID == "AN050"):
			print ("AN050 |       X")
		if (enterAnID == "an051" or enterAnID == "An051" or enterAnID == "AN051"):
			print ("AN051 |       Y")
		if (enterAnID == "an052" or enterAnID == "An052" or enterAnID == "AN052"):
			print ("AN052 |       Z")
		#else:
			#print ("Unknown ID entered ")
		continueEnt = input("Press [ENTER] key to continue")
	if (categoryStrEnter == "BULLET" or categoryStrEnter == "Bullet" or categoryStrEnter == "bullet"):
		print ("Bullet character sheet - UCALC Char sheet")
		print ("\n")
		print ("|=======================================================================================================================|")
		print ("| • | U2022 | ? | U0000 | ? | U0000 | ? | U0000 | ? | U0000 | ? | U0000 | ? | U0000 | ? | 00000 | ? | U0000 | ? | U0000 |")
		print ("|=======================================================================================================================|")
		enterAnID = str(input("Enter an ID to continue: "))
		if (enterAnID == "U2022" or enterAnID == "u2022"):
			print ("U2002 'bullet' | •")
		continueEnt = input("Press [ENTER] key to continue")
	if (categoryStrEnter == "CURRENCY" or categoryStrEnter == "Currency" or categoryStrEnter == "currency"):
		print ("Currency Character sheet - UCALC Char sheet")
		print ("\n")
		print ("|=======================================================================================================================|")
		print ("| $ | U0024 | ¢ | U00A2 | £ | U00A3 | ¤ | U00A4 | ¥ | U00A5 | ₠ | U20A0 | ₡ | U20A1 | ₢ | U20A2 | ₣ | U20A3 | ₤ | U20A4 |")
		print ("| ₥ | U20A5 | ₦ | U20A6 | ₧ | U20A7 | ₨ | U20A8 | ₩ | U20A9 | ₪ | U20AA | ₫ | U20AB | € | U20AC | ₭ | U20AD | ₮ | U20AE |")
		print ("| ₯ | U20AF | ₰ | U20B0 | ₱ | U20B1 | ₲ | U20B2 | ₳ | U20B3 | ₴ | U20B4 | ₵ | U20B5 | ₶ | U20B6 |=======================|")
		print ("|===============================================================================================|")
		enterAnID = str(input("Enter an ID to start: "))
		if (enterAnID == "u0024" or enterAnID == "U0024"):
			print ("| U0024 | Dollar sign | $")
		if (enterAnID == "u00A2" or enterAnID == "U00A2"):
			print ("| U00A2 | Cent sign   | ¢")
		if (enterAnID == "u00A3" or enterAnID == "U00A3"):
			print ("| U00A3 | Pound sign  | £")
		if (enterAnID == "u00A4" or enterAnID == "U00A4"):
			print ("| U00A4 | Currency sign | ¤")
		if (enterAnID == "u00A5" or enterAnID == "U00A5"):
			print ("| U00A5 | Yen sign | ¥")
		if (enterAnID == "u20A0" or enterAnID == "U20A0"):
			print ("| U20A0 | Euro-currency sign | ₠")
		if (enterAnID == "u20A1" or enterAnID == "U20A1"):
			print ("| U20A1 | Colon sign | ₡")
		if (enterAnID == "u20A2" or enterAnID == "U20A2"):
			print ("| U20A2 | Cruzeiro sign | ₢")
		if (enterAnID == "u20A3" or enterAnID == "U20A3"):
			print ("| U20A3 | French Franc Sign | ₣")
		if (enterAnID == "u20A4" or enterAnID == "U20A4"):
			print ("| U20A4 | Lira sign | ₤")
		if (enterAnID == "u20A5" or enterAnID == "U20A5"):
			print ("| U20A5 | Mill sign | ₥")
		if (enterAnID == "u20A6" or enterAnID == "U20A6"):
			print ("| U20A6 | Naira sign | ₦")
		if (enterAnID == "u20A7" or enterAnID == "U20A7"):
			print ("| U20A7 | Peseta sign | ₧")
		if (enterAnID == "u20A8" or enterAnID == "U20A8"):
			print ("| U20A8 | Rupee Sign | ₨")
		if (enterAnID == "u20A9" or enterAnID == "U20A9"):
			print ("| U20A9 | Won sign | ₩")
		if (enterAnID == "u20AA" or enterAnID == "U20AA"):
			print ("| U20AA | New Sheqel sign | ₪")
		if (enterAnID == "u20AB" or enterAnID == "U20AB"):
			print ("| U20AB | Dong sign | ₫")
		if (enterAnID == "u20AC" or enterAnID == "U20AC"):
			print ("| U20AC | Euro sign | €")
		if (enterAnID == "u20AD" or enterAnID == "U20AD"):
			print ("| U20AD | Kip sign | ₭")			
		if (enterAnID == "u20AE" or enterAnID == "U20AE"):
			print ("| U20AE | Tugrik sign | ₮")
		if (enterAnID == "u20AF" or enterAnID == "U20AF"):
			print ("| U20AF | Drachma sign | ₯")
		if (enterAnID == "u20B0" or enterAnID == "U20B0"):
			print ("| U20B0 | German Penny Sign | ₰")
		if (enterAnID == "u20B1" or enterAnID == "U20B1"):
			print ("| U20B1 | Peso sign | ₱")
		if (enterAnID == "u20B2" or enterAnID == "U20B2"):
			print ("| U20B2 | Guarani sign | ₲")
		if (enterAnID == "u20B3" or enterAnID == "U20B3"):
			print ("| U20B3 | Austrian sign | ₳")
		if (enterAnID == "u20B4" or enterAnID == "U20B4"):
			print ("| U20B4 | Hryvnia sign | ₴")
		if (enterAnID == "u20B5" or enterAnID == "U20B5"):
			print ("| U20B5 | Cedi sign | ₵")
		if (enterAnID == "u20B6" or enterAnID == "U20B6"):
			print ("| U20B6 | Livre Tournois Sign | ₶")
		continueEnt = input("Press [ENTER] key to continue")
	if (categoryStrEnter == "DOS" or categoryStrEnter == "Dos" or categoryStrEnter == "dos"):
		print ("DOS Character sheet - UCALC Char sheet")
		print ("\n")
		print ("|=======================================================================================================================|")
		print ("| ░ | U2591 | ▒ | U2592 | ▓ | U2593 |===================================================================================|")
		print ("|===================================|")
		enterAnID = str(input("Enter an ID to start: "))
		if (enterAnID == "u2591" or enterAnID == "U2591"):
			print ("| U2591 | Light shade | ░")
		if (enterAnID == "u2592" or enterAnID == "U2592"):
			print ("| U2592 | Medium shade | ▒")
		if (enterAnID == "u2593" or enterAnID == "U2593"):
			print ("| U2593 | Dark shade | ▓")
		continueEnt = input("Press [ENTER] key to continue")
	if (categoryStrEnter == "MUSICAL NOTES" or categoryStrEnter == "Musical notes" or categoryStrEnter == "musical notes" or categoryStrEnter == "Musical Notes"):
		print ("Musical Notes Character sheet - UCALC Char sheet")
		print ("\n")
		print ("|=======================================================================================================================|")
		print ("| ♪ | U266A | ♫ | U266B | ♯ | U266C |===================================================================================|")
		print ("|===================================|")
		enterAnID = str(input("Enter an ID to start: "))
		if (enterAnID == "u266A" or enterAnID == "U266A"):
			print ("| U266A | Eighth note | ♪")
		if (enterAnID == "u266B" or enterAnID == "U266B"):
			print ("| U266B | Beamed eighth notes | ♫")
		if (enterAnID == "u266C" or enterAnID == "U266C"):
			print ("| U266C | Music sharp sign | ♯")
		continueEnt = input("Press [ENTER] key to continue")
	if (categoryStrEnter == "CHESS AND CHECKERS" or categoryStrEnter == "Chess and checkers" or categoryStrEnter == "chess and checkers"):
		print ("Chess and checkers character sheet - UCALC Char sheet")
		print ("\n")
		print ("|=======================================================================================================================|")
		print ("| ♠ | U2660 | ♣ | U2663 | ♥ | U2665 | ♦ | U2666 | ? | U0000 | ? | U0000 | ? | U0000 | ? | U0000 | ? | U0000 | ? | U0000 |")
		print ("|========================================================================================================================")
		enterAnID = str(input("Enter an ID to start: "))
		if (enterAnID == "u2660" or enterAnID == "U2660"):
			print ("| U2660 | Black Spade Suit | ♠")
		if (enterAnID == "u2663" or enterAnID == "U2663"):
			print ("| U2663 | Black Club Suit | ♣") 
		if (enterAnID == "u2665" or enterAnID == "U2665"):
			print ("| U2665 | Black Heart Suit | ♥")
		if (enterAnID == "u2666" or enterAnID == "U2666"):
			print ("| U2666 | Black Diamond Suit | ♦")
		continueEnt = input("Press [ENTER] key to continue")
noMore = input("Press [ENTER] key to quit")
'''
Character sheet
Version 1.0.0.0.0
December 24th 2018 to December 28th 2018 build
Written by Sean Myrick
Language: Python 3x 
Inspired by:
* Microsoft Windows character map
* oldschool computers 
* computers with broken keys
'''