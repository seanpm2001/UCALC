print ("ASCII table")
print ("(!) note: this program is locked in 8 bit mode")
entAscii = int(input("Enter a number (0-255) to returnits ASII character: "))
entAscii2 = int
entAscii2 == entAscii
while (entAscii == entAscii):
	if (entAscii > 0 and entAscii < 256):
		print (chr(entAscii) + " " + str(entAscii))
		more1 = input("========")
		entAscii = entAscii + 1
	else:
		print ("Invalid number entered!")
		noMore = input("Press [ENTER] key to quit")
noMore = input("Press [ENTER] key to quit")

