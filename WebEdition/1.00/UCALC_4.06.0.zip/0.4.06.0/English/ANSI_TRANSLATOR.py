				if calcIDSes == 59:
					print ("ANSI Translator")
					ansint = int(input("Enter a number (1-90) to translate it to its ANSI character"))
					print ("The translated symbol is: ")
					if ansint == 1:
						print (ansi.aa)
					if ansint == 2:
						print (ansi.ab)
					if ansint == 3:
						print (ansi.ac)
					if ansint == 4:
						print (ansi.ad)
					if ansint == 5:
						print (ansi.ae)
					if ansint == 6:
						print (ansi.af)
					if ansint == 7:
						print (ansi.ag)
					if ansint == 8:
						print (ansi.ah)
					if ansint == 9:
						print (ansi.ai)
					if ansint == 10:
						print (ansi.aj)
					if ansint == 11:
						print (ansi.ak)
					if ansint == 12:
						print (ansi.al)
					if ansint == 13:
						print (ansi.am)
					if ansint == 14:
						print (ansi.an)
					if ansint == 15:
						print (ansi.ao)
					if ansint == 16:
						print (ansi.ap)
					if ansint == 17:
						print (ansi.aq)
					if ansint == 18:
						print (ansi.ar)
					if ansint == 19:
						print (ansi.as1)
					if ansint == 20:
						print (ansi.at)
					if ansint == 21:
						print (ansi.au)
					if ansint == 22:
						print (ansi.av)
					if ansint == 23:
						print (ansi.aw)
					if ansint == 24:
						print (ansi.ax)
					if ansint == 25:
						print (ansi.ay)
					if ansint == 26:
						print (ansi.az)
					if ansint == 27:
						print (ansi.ba)
					if ansint == 28:
						print (ansi.bb)
					if ansint == 29:
						print (ansi.bc)
					if ansint == 30:
						print (ansi.bd)
					if ansint == 31:
						print (ansi.be)
					if ansint == 32:
						print (ansi.bf)
					if ansint == 33:
						print (ansi.bg)
					if ansint == 34:
						print (ansi.bh)
					if ansint == 35:
						print (ansi.bi)
					if ansint == 36:
						print (ansi.bj)
					if ansint == 37:
						print (ansi.bk)
					if ansint == 38:
						print (ansi.bl)
					if ansint == 39:
						print (ansi.bm)
					if ansint == 40:
						print (ansi.bn)
					if ansint == 41:
						print (ansi.bo)
					if ansint == 42:
						print (ansi.bp)
					if ansint == 43:
						print (ansi.bq)
					if ansint == 44:
						print (ansi.br)
					if ansint == 45:
						print (ansi.bs)
					if ansint == 46:
						print (ansi.bt)
					if ansint == 47:
						print (ansi.bu)
					if ansint == 48:
						print (ansi.bv)
					if ansint == 49:
						print (ansi.bw)
					if ansint == 50:
						print (ansi.bx)
					if ansint == 51:
						print (ansi.by)
					if ansint == 52:
						print (ansi.bz)
					if ansint == 53:
						print (ansi.ca)
					if ansint == 54:
						print (ansi.cb)
					if ansint == 55:
						print (ansi.cc)
					if ansint == 56:
						print (ansi.cd)
					if ansint == 57:
						print (ansi.ce)
					if ansint == 58:
						print (ansi.cf)
					if ansint == 59:
						print (ansi.cg)
					if ansint == 60:
						print (ansi.ch)
					if ansint == 61:
						print (ansi.ci)
					if ansint == 62:
						print (ansi.cj)
					if ansint == 63:
						print (ansi.ck)
					if ansint == 64:
						print (ansi.cl)
					if ansint == 65:
						print (ansi.cm)
					if ansint == 66:
						print (ansi.cn)
					if ansint == 67:
						print (ansi.co)
					if ansint == 68:
						print (ansi.cp)
					if ansint == 69:
						print (ansi.cq)
					if ansint == 70:
						print (ansi.cr)
					if ansint == 71:
						print (ansi.cs)
					if ansint == 72:
						print (ansi.ct)
					if ansint == 73:
						print (ansi.cu)
					if ansint == 74:
						print (ansi.cv)
					if ansint == 75:
						print (ansi.cw)
					if ansint == 76:
						print (ansi.cx)
					if ansint == 77:
						print (ansi.cy)
					if ansint == 78:
						print (ansi.cz)
					if ansint == 79:
						print (ansi.da)
					if ansint == 80:
						print (ansi.db)
					if ansint == 81:
						print (ansi.dc)
					if ansint == 82:
						print (ansi.dd)
					if ansint == 83:
						print (ansi.de)
					if ansint == 84:
						print (ansi.df)
					if ansint == 85:
						print (ansi.dg)
					if ansint == 86:
						print (ansi.dh)
					if ansint == 87:
						print (ansi.di)
					if ansint == 88:
						print (ansi.dj)
					if ansint == 89:
						print (ansi.dk)
					if ansint == 90:
						print (ansi.dl)
					noMore = input("Press [ENTER] key to exit")