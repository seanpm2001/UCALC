gameselectID = int(11)
if gameselectID == 11:
	if gameselectID == 11:
		if gameselectID == 11:
			if gameselectID == 11:
				if gameselectID == 11:
					if gameselectID == 11:
						print ("Launch the X")
						print ("A game for the delusional")
						print ("\n\n")
						launchx1 = input("Press [ENTER] key to start")
						megalaunch = (1)
						while megalaunch == (1):
							print ("   x   ")
							launchx2 = input("Press [ENTER] to launch the X")
							print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
							print ("All Xcrafts have been launched")
							exit = input("Press [ENTER] key to quit")