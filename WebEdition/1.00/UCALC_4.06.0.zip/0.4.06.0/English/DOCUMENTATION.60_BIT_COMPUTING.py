WikIDSelect = int(20014)
if WikIDSelect == 20014:
	if WikIDSelect == 20014:
		if WikIDSelect == 20014:
			if WikIDSelect == 20014:
				print ("In computer architecture, 60-bit integers, memory addresses, or other data units are those that are 60 bits wide. Also, ")
				print ("60-bit CPU and ALU architectures are those that are based on registers, address buses, or data buses of that size.")
				print (" ")
				print ("Computers with 60-bit words include the CDC 6000 series, the CDC 7600, and some of the CDC Cyber series. ")
				print (" ")
				noMore = input("Press [ENTER] key to exit")