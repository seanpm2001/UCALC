WikIDSelect = int(30001)
if WikIDSelect == 30001:
	if WikIDSelect == 30001:
		if WikIDSelect == 30001:
			if WikIDSelect == 30001:
				print ("This section is not yet available")
				noMore = input("Press [ENTER] key to exit")
				print ("Exiting")
				print ("Please wait...")