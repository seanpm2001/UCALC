WikIDSelect = int(10013)
if WikIDSelect == 10013:
	if WikIDSelect == 10013:
		if WikIDSelect == 10013:
			if WikIDSelect == 10013:
				print ("Comment section")