				if calcIDSes == 58:
					print ("Windows key generator")
					print ("\nVersion 1")
					continueToKeys = input("\n\n\n\nPress [ENTER] key to begin setup")
					print ("[Windows 95 (ID: 10) ]  [Windows NT 4.0 (ID: 11) ]  [Windows 98  (ID: 12) ]")
					print ("[Windows ME (ID: 13) ]  [Windows 2000   (ID: 14) ]  [Windows XP  (ID: 15) ]")
					print ("[Windows 03 (ID: 16) ]  [Windows Vista  (ID: 17) ]  [Windows 08  (ID: 18) ]")
					print ("[Windows 7  (ID: 19) ]  [Windows 8      (ID: 20) ]  [Windows 012 (ID: 21) ]")
					print ("[Windows 8.1(ID: 22) ]  [Windows 016    (ID: 23) ]  [Windows 10  (ID: 24) ]")
					print ("[Windows 19 (ID: 25) ]  [Windows 95+    (ID: 26) ]  [Windows 98+ (ID: 27) ]")
					print ("[Office 97  (ID: 28) ]  [Office 2000    (ID: 29) ]  [Office XP   (ID: 30) ]")
					print ("[Office 2003(ID: 31) ]  [Office 2007    (ID: 32) ]  [Office 2010 (ID: 33) ]")
					print ("[Office 2013(ID: 34) ]  [Office 2016    (ID: 35) ]  [Office 2019 (ID: 36) ]")
					print ("[Office 95  (ID: 37) ]  [************************]  [*********************]")
					selectWindows1 = int(input("\n\nEnter an ID: "))
					if selectWindows1 == 10:
						print ("Windows 95 key generator")
						selectWin95KeyMasterRandom = input("Press [ENTER] key to generate a Windows 95 product key")
						win95keyMasterRan == int(random.randint(1, 6))
						if win95keyMasterRan == 1:
							print ("Working Windows 95 product key:\n100-1208613")
						if win95keyMasterRan == 2:
							print ("Working Windows 95 product key:\n757-2573155")
						if win95keyMasterRan == 3:
							print ("Working Windows 95 product key:\n875-7215850")
						if win95keyMasterRan == 4:
							print ("Working Windows 95 product key:\n900-9262036")
						if win95keyMasterRan == 5:
							print ("Working Windows 95 product key:\n900-9262045")
						if win95keyMasterRan == 6:
							print ("Working Windows 95 product key:\n")
					if selectWindows1 == 11:
						print ("Windows NT 4.0 key generator")
					if selectWindows1 == 12:
						print ("Windows 98 key generator")
						more1 = input("Press [ENTER] key to generate a Windows 98 product key")
						win98KeyMasterRan = int(random.randint(1, 12))
						if win98KeyMasterRan == 1:	
							print ("Working Windows 98 product key:\nF73WT-WHD3J-CD4VR-2GWKD-T38YD")
						if win98KeyMasterRan == 2:	
							print ("Working Windows 98 product key:\nR667M-TF9CG-MJMTM-WHPWQ-G6XGG")
						if win98KeyMasterRan == 3:	
							print ("Working Windows 98 product key:\nB3PJW-2FCXF-6P7K6-8T8H3-7V3RT")
						if win98KeyMasterRan == 4:	
							print ("Working Windows 98 product key:\nBM9FY-V6Y3V-GRM3B-3WTTR-PTBWT")
						if win98KeyMasterRan == 5:	
							print ("Working Windows 98 product key:\nBW8X2-647MH-CM8X2-4PD9V-B2CKG")
						if win98KeyMasterRan == 6:	
							print ("Working Windows 98 product key:\nC3MH2-8DP7G-JGQ7F-PM73H-YB3PT")
						if win98KeyMasterRan == 7:	
							print ("Working Windows 98 product key:\nC4GMB-B23QQ-QPRCH-QX2C8-9CJVW")
						if win98KeyMasterRan == 8:	
							print ("Working Windows 98 product key:\nC79C6-Q9YKH-YTBQ9-8B7WB-T9GGM")
						if win98KeyMasterRan == 9:	
							print ("Working Windows 98 product key:\nCD649-PKJTQ-KHWPM-TC43M-RDRFG")
						if win98KeyMasterRan == 10:	
							print ("Working Windows 98 product key:\nD4MXG-3QX3F-TX86C-FPBF4-6YXQT")
						if win98KeyMasterRan == 11:	
							print ("Working Windows 98 product key:\nDBWVG-BK79Y-CVT9H-CYRGX-3TKCT")
						if win98KeyMasterRan == 12:	
							print ("Working Windows 98 product key:\nDBYJ8-F2YW8-FRVXC-R7QXV-47RF6")
					if selectWindows1 == 13:
						print ("Windows Millenium Edition key generator")
						more1 = input("Press [ENTER] key to generate a Windows ME product key")
						winMEKeyMasterRan = int(random.randint(1,6))
						if winMEKeyMasterRan == 1:
							print ("Working Windows ME product key:\nB88DH-VQ89B-G4WWK-DCBP2-7B7PW")
						if winMEKeyMasterRan == 2:
							print ("Working Windows ME product key:\nFMMMC-G8GQH-BH9MT-YBRH3-CRD6T")
						if winMEKeyMasterRan == 3:
							print ("Working Windows ME product key:\nHBTD9-6P338-XT2MV-QBTTF-WPGGB")
						if winMEKeyMasterRan == 4:
							print ("Working Windows ME product key:\nJ7C6X-QC2BH-GGX24-7FQG7-2K398")
						if winMEKeyMasterRan == 5:
							print ("Working Windows ME product key:\nKKK3F-QKXGY-WHG99-B92WK-GFK4C")
						if winMEKeyMasterRan == 6:
							print ("Working Windows ME product key:\nP8DJW-RQXXM-T8JCW-HFB29-4FK3Y")
					if selectWindows1 == 14:
						print ("Windows 2000 key generator")
						more1 = input("Press [ENTER] key to generate a Windows 2000 product key")
						win2KKeyMasterRan = int(random.randint(1,7))
						if win2KKeyMasterRan == 1:
							print ("Working Windows 2000 product key:\nWMCVC-CD8D9-PB93H-TW8KQ-D42QY")
						if win2KKeyMasterRan == 2:
							print ("Working Windows 2000 product key:\nBCHQB-PMWJ3-CQRQC-GX7BT-RDFCP")
						if win2KKeyMasterRan == 3:
							print ("Working Windows 2000 product key:\nJYTQH-KFCRD-8MQRT-XG9CM-FF63Y")
						if win2KKeyMasterRan == 4:
							print ("Working Windows 2000 product key:\nRM233-2PRQQ-FR4RH-JP89H-46QYB")
						if win2KKeyMasterRan == 5:
							print ("Working Windows 2000 product key:\nDDTPW-TXMX7-BBGJ9-WGY8K-B9GHM")
						if win2KKeyMasterRan == 6:
							print ("Working Windows 2000 product key:\nTCJCY-H2QDH-3T7G7-R6RTM-YRK3Y")
						if win2KKeyMasterRan == 7:
							print ("Working Windows 2000 product key:\nH6TWQ-TQQM8-HXJYG-D69F7-R84VM")
					if selectWindows1 == 15:
						print ("Windows XP key generator")
						selectWinXPKeyMasterRandom = input("Press [ENTER] key to generate a Windows XP product key")
						winXPKeyMasterRan = int(random.randint(1, 2))
						if winXPKeyMasterRan == 1:
							print ("Working Windows XP product key:\nHQYPY-PP489-77M9R-R4QHW-7MM2G") # this key was distributed to me from my brother-in-law Channa My (Azure developer at Microsoft)
						if winXPKeyMasterRan == 2:
							print ("Working Windows XP product key:\nR4JPP-RQDBV-4PHTX-7MY3T-DGVTB") # this key was also distributed to me from my brother-in-law Channa My (Azure developer at Microsoft)
						if winXPKeyMasterRan == 3:
							print ("Working Windows XP product key:\nBJXGH-4TG7P-F9PRP-K6FJD-JQMPM")
						if winXPKeyMasterRan == 4:
							print ("Working Windows XP product key:\nDTWB2-VX8WY-FG8R3-X696T-66Y46")
						if winXPKeyMasterRan == 5:
							print ("Working Windows XP product key:\nDW3CF-D7KYR-KMR6C-3X7FX-T8CVM")
						if winXPKeyMasterRan == 6:
							print ("Working Windows XP product key:\nDW87C-76RXP-LLK6C-3FJ2J-2908F")
						if winXPKeyMasterRan == 7:
							print ("Working Windows XP product key:\nF6PGG-4YYDJ-3FF3T-R328P-3BXTG")
						if winXPKeyMasterRan == 8:
							print ("Working Windows XP product key:\nFM9FY-TMF7Q-KCKCT-V9T29-TBBBG")
						if winXPKeyMasterRan == 9:
							print ("Working Windows XP product key:\nJJWKH-7M9R8-26VM4-FX8CC-GDPD8")
						if winXPKeyMasterRan == 10:
							print ("Working Windows XP product key:\nKWT78-4D939-MRKK9-64W8C-CPFD8")
						if winXPKeyMasterRan == 11:
							print ("Working Windows XP product key:\nMQPD6-C748R-FMRV6-8C3QK-7PK9Q")
						if winXPKeyMasterRan == 12:
							print ("Working Windows XP product key:\nQ3R8Y-MP9KD-3M6KB-383YB-7PK9Q")
						if winXPKeyMasterRan == 13:
							print ("Working Windows XP product key:\nQB2BW-8PJ2D-9X7JK-BCCRT-D233Y")
						if winXPKeyMasterRan == 14:
							print ("Working Windows XP product key:\nRBDC9-VTRC8-D7972-J97JY-PRVMG")
						if winXPKeyMasterRan == 15:
							print ("Working Windows XP product key:\nRK7J8-2PGYQ-4P7VL-V6PMB-F6XPQ")
					if selectWindows1 == 16:
						print ("Windows Server 2003 key generator")
					if selectWindows1 == 17:
						print ("Windows Vista key generator")
					if selectWindows1 == 18:
						print ("Windows Server 2008 key generator")
						print ("ERROR! This generator is unavailable as the operating system was still supported when this version was released")
					if selectWindows1 == 19:
						print ("Windows 7 key generator")
						print ("ERROR! This generator is unavailable as the operating system was still supported when this version was released")
					if selectWindows1 == 20:
						print ("Windows 8 key generator")
					if selectWindows1 == 21:
						print ("Windows Server 2012 key generator")
						print ("ERROR! This generator is unavailable as the operating system was still supported when this version was released")
					if selectWindows1 == 22:
						print ("Windows 8.1 key generator")
						print ("ERROR! This generator is unavailable as the operating system was still supported when this version was released")
					if selectWindows1 == 23:
						print ("Windows Server 2016 key generator")
						print ("ERROR! This generator is unavailable as the operating system was still supported when this version was released")
					if selectWindows1 == 24:
						print ("Windows 10 key generator")
						print ("ERROR! This generator is unavailable as the operating system was still supported when this version was released")
					if selectWindows1 == 25:
						print ("Windows Server 2019 key generator")
						print ("ERROR! This generator is unavailable as the operating system was still supported when this version was released")
					if selectWindows1 == 26:
						print ("Windows 95 plus product key generator")
						more1 = input("Press [ENTER] key to generate a Windows 95 plus! key")
						win95pKeyMasterRan = int(random.randint(1, 3))
						if win95pKeyMasterRan == 1:
							print ("Working Windows 95 plus! key:\n040-0073635")
						if win95pKeyMasterRan == 2:
							print ("Working Windows 95 plus! key:\n040-0081471")
						if win95pKeyMasterRan == 3:
							print ("Working Windows 95 plus! key:\n040-0081586")	
					if selectWindows1 == 27:
						print ("Windows 98 plus product key generator")
						more1 = input("Press [ENTER] key to generate a Windows 98 plus! key")
						win98pKeyMasterRan = int(random.randint(1, 2))
						if win98pKeyMasterRan == 1:
							print ("Working Windows 98 plus! key:\n411-2781863")
						if win98pKeyMasterRan == 2:
							print ("Working Windows 98 plus! key:\n450-0535503")
					if selectWindows1 == 28:
						print ("Office 97 product key generator")
						more1 = input("Press [ENTER] key to generate a Microsoft Office 97 product key")
						msoff97pKeyMasterRan = int(random.randint(1, 4))
						if msoff97pKeyMasterRan == 1:
							print ("Working Office 97 product key:\n9001-9353861")
						if msoff97pKeyMasterRan == 2:
							print ("Working Office 97 product key:\n9001-9353877")
						if msoff97pKeyMasterRan == 3:
							print ("Working Office 97 product key:\n4667-0009847")
						if msoff97pKeyMasterRan == 4:
							print ("Working Office 97 product key:\n8068-2570043")
					if selectWindows1 == 29:
						print ("Office 2000 product key generator")
						more1 = input("Press [ENTER] key to generate a Microsoft Office 2000 product key")
						msoff2kpKeyMasterRan = int(random.randint(1,3))
						if msoff2kpKeyMasterRan == 1:
							print ("Working Microsoft Office 2000 product key:\nWQCW8-6YWF9-TDW73-697YX-CJH3Y")
						if msoff2kpKeyMasterRan == 2:
							print ("Working Microsoft Office 2000 product key:\nT3KB9-4KCJF-D3H36-TDR47-RMMWK")
						if msoff2kpKeyMasterRan == 3:
							print ("Working Microsoft Office 2000 product key:\nBGF6V-R7323-2CKHJ-R37XF-T9BFT")
					if selectWindows1 == 30:
						print ("Office XP product key generator")
						more1 = input("Press [ENTER] key to generate a Microsoft Office XP product key")
						msoffxpKeyMasterRan = int(random.randint(1,2))
						if msoffxpKeyMasterRan == 1:
							print ("Working Microsoft Office XP product key:\nFM9FY-TMF7Q-KCKCT-V9T29-TBBBG")
						if msoffxpKeyMasterRan == 2:
							print ("Working Microsoft Office XP product key:\nP3TJ7-4P6MP-7BPDD-6V67F-9FM8Q")
					if selectWindows1 == 31:
						print ("Office 2003 product key generator")
						more1 = input("Press [ENTER] key to generate a Microsoft Office 2003 product key")
						msoff03KeyMasterRan = int(random.randint(1,2))
						if msoff03KeyMasterRan == 1:
							print ("Unable to generate a product key for this product")
						if msoff03KeyMasterRan == 2:
							print ("Unable to generate a product key for this product")				
					if selectWindows1 == 32:
						print ("Office 2007 product key generator")
						more1 = input("Press [ENTER] key to generate a Microsoft Office 2007 product key")
						msoff07KeyMasterRan = int(random.randint(1,2))
						if msoff07KeyMasterRan == 1:
							print ("Unable to generate a product key for this product")
						if msoff07KeyMasterRan == 2:
							print ("Unable to generate a product key for this product")
					if selectWindows1 == 33:
						print ("Office 2010 product key generator")
						more1 = input("Press [ENTER] key to generate a Microsoft Office 2010 product key")
						msoff10KeyMasterRan = int(random.randint(1,2))
						if msoff10KeyMasterRan == 1:
							print ("Unable to generate a product key for this product")
						if msoff10KeyMasterRan == 2:
							print ("Unable to generate a product key for this product")
						more1 = input("Press [ENTER] key to generate a Microsoft Office 2003 product key")
					if selectWindows1 == 34:
						print ("Office 2013 product key generator")
						more1 = input("Press [ENTER] key to generate a Microsoft Office 2013 product key")
						msoff13KeyMasterRan = int(random.randint(1,2))
						if msoff13KeyMasterRan == 1:
							print ("Unable to generate a product key for this product")
						if msoff13KeyMasterRan == 2:
							print ("Unable to generate a product key for this product")
					if selectWindows1 == 35:
						print ("Office 2016 product key generator")
						more1 = input("Press [ENTER] key to generate a Microsoft Office 2016 product key")
						msoff16KeyMasterRan = int(random.randint(1,2))
						if msoff16KeyMasterRan == 1:
							print ("Unable to generate a product key for this product")
						if msoff16KeyMasterRan == 2:
							print ("Unable to generate a product key for this product")
					if selectWindows1 == 36:
						print ("Office 2019 product key generator")
						more1 = input("Press [ENTER] key to generate a Microsoft Office 2019 product key")
						msoff19KeyMasterRan = int(random.randint(1,2))
						if msoff19KeyMasterRan == 1:
							print ("Unable to generate a product key for this product")
						if msoff19KeyMasterRan == 2:
							print ("Unable to generate a product key for this product")
						more1 = input("Press [ENTER] key to generate a Microsoft Office 2019 product key")
					if selectWindows1 == 37:
						print ("Office 95 product key generator")
						more1 = input("Press [ENTER] key to generate a Microsoft Office 2003 product key")
						msoff95KeyMasterRan = int(random.randint(1,2))
						if msoff95KeyMasterRan == 1:
							print ("Unable to generate a product key for this product")
						if msoff95KeyMasterRan == 2:
							print ("Unable to generate a product key for this product")
					print ("Enjoy your new key!")
					'''
					QUICK ACCESS
					Angel fire key list | http://www.angelfire.com/ms2/mstech9x/info/Product_Key_List.htm
					Product Key List
	 
	Windows 95


	100-1208613
	757-2573155
	757-2573155
	875-7215850
	900-9262036
	900-9262045
	03002-OEM-0009165-66024
	12095-OEM-0004226-12233
	12899-OEM-0042134-31009
	12899-OEM-0042134-31013
	12899-OEM-0042134-32969
	12899-OEM-0042134-35045
	13895-OEM-0000736-75397
	15096-OEM-0012846-52764
	15795-OEM-0001355-07757
	16595-OEM-0001695-96524
	24796-OEM-0014736-66386
	26996-OEM-0015582-21990
	27497-OEM-0025347-80387
	31795-OEM-0006627-29381
	35201-OEM-0009165-64718
	Plus! 95:
	040-0073635
	040-0081471
	040-0081586


	 
	Windows 98

	F73WT-WHD3J-CD4VR-2GWKD-T38YD

	ProdKey3 Windows 98 00003 OEM FPP: R667M-TF9CG-MJMTM-WHPWQ-G6XGG
	ProdKey3 Windows 98 00003 OEM FPP: VY24V-D7M3M-6VGCC-C6667-6Q3G3
	MEDIA SET CD Windows 98 English FPP REFRESH: C2BCY-MB3XG-DQ6MW-F2DPD-4X7QT
	MEDIA SET CD Windows 98 English FPP REFRESH: WCH2T-76GG7-2QKK9-2QHB8-TBH6J
	MEDIA SET CD Windows 98 English FPP REFRESH: WVC4P-F6KM4-V7F3P-3GP7M-PCFGM
	MEDIA SET CD Windows 98 English FPP REFRESH: JHMRC-BDWBB-6J4HC-4MPKX-39KHD
	CCP BYPASS ProdKey3 Windows Syst 00002 CCP Rtl: VMFRF-C9F74-P34DP-28JPJ-6V6KP
	CCP BYPASS ProdKey3 Windows Syst 00002 CCP Rtl: JF8QQ-X9CHQ-6P4XV-H69WQ-PD7G4
	CCP BYPASS ProdKey3 Windows Syst 00002 CCP Rtl: T8J3F-M3B2Q-44KJP-TBTJ9-VGFRF


	B3PJW-2FCXF-7P7K6-8T8H3-7V3RT
	BM9FY-V6Y3V-GRM3B-3WTTR-PTBWT
	BW8X2-647MH-CM8X2-4PD9V-B2CKG
	C3MH2-8DP7G-JGQ7F-PM73H-YB3PT
	C4GMB-B23QQ-QPRCH-QX2C8-9CJVW
	C79C6-Q9YKH-YTBQ9-8B7WB-T9GGM
	CD649-PKJTQ-KHWPM-TC43M-RDRFG
	D4MXG-3QX3F-TX86C-FPBF4-6YXQT
	DBWVG-BK79Y-CVT9H-CYRGX-3TKCT
	DBYJ8-F2YW8-FRVXC-R7QXV-47RF6
	DHVMR-K4J3J-X7Y7M-W2HBP-CGHCT
	DMGFK-MWMMQ-QRHBF-GYTMJ-CW676
	DT9BD-K7W9C-YB4K6-2RQXD-K2HDW
	DX7RB-9W9GR-KFBMV-ZXHHR-JJP6T
	FCXFG-4XG3P-32RXV-PVBDB-44DWT
	FD97P-B3K2G-PBX37-HXXGJ-J83CT
	FG7DK-CW2D3-BQHW2-F8PMW-862K6
	FHDYC-CTKH7-36JY7-78CYW-YVRH6
	FQD88-4X7FK-9HV9K-Q28FF-T3JC3
	FVV68-CP77T-3VFBV-J39XB-PBKHB
	FX2HD-PTD89-MG7WX-KV82X-MH3PG
	FXJGV-V47K8-9TKJ3-4UVBT-CTCFW
	G2FGT-6HYRW-X2W2C-RT7HW-RF7WX
	G7YTJ-BX4VT-YXXDC-343Y7-QJJ9G
	G8KJY-X4KVK-FQPV8-HG77P-TRYCG
	GBPTG-VHDDV-KP748-2J8RV-QPVGY
	GDW28-QT37B-RP74D-4VHTY-B6BHT
	GTVHQ-B8V2Y-76T9Y-XBMFY-3396V
	GV7K8-QHDY3-VCRYV-P6PVB-KHQGT
	GXQ6D-XFH8V-CVXHD-HHMGV-BJKQG
	GYW4M-7MHT7-DR32K-8PB48-XXM7G
	HC369-2D8CV-8P273-44Y9K-GQXC3
	HCD6T-Q3M6B-M2BTQ-V7B7B-6BCHT
	HH872-6RM2K-FPPWV-V9HDB-BK708
	HRVCP-2GGVH-KMTTG-67GRP-HJRDT
	HWD3T-8WVCD-HVCB6-M9VH8-YVB2T
	J4B42-K63WB-8FX6F-2GGHG-TQFFG
	J6BMM-4X366-C6C4R-QVGYK-G8J8T
	J82GP-JRHK2-8KHGM-39BX7-2TPF6
	JTPVT-BY4R6-QY3PY-4C6DD-3YTGQ
	JX6HD-WWGH6-JKR8G-WV7QB-44DQ6
	K362Y-XQZHT-DWKMK-WGR9J-Q7376
	K4HVD-Q9TJ9-6CRX9-C9G68-RQ2D3
	KBVY8-JFBWF-DKGQQ-MRPVD-P4G2T
	KW66V-8BGQD-J2F9W-K32YQ-RPM4T
	M3GQF-JP78W-8VBJX-6KVQD-8M2G6
	M7PWN-TMMHG-C8J6D-KWPJR-R38XG
	M9VVF-RTDY3-FXGXF-YT9BC-FVDPG
	MBX63-XPC3R-FKM7W-J2YR2-R7JCM
	MCYWR-VV8K8-PTKDQ-FPP3G-W29DG
	MRGG9-G64FB-6DK34-7Q6RD-7V3R6
	MZY7R-W3MB7-R6P83-HB6R9-9JCHG
	P688V-96M43-2JK2R-VYXJR-WVRDT
	PQKKT-QB2KH-D2KBV-BD6HT-8XJX6
	PYDMY-DVJ9J-996VH-JX66P-9TWKW
	Q7HGD-G4FPY-28YGM-RDF4R-6RT7T
	Q7W2M-9VPFY-32WKD-M8QVQ-CFJFG
	Q888R-DJRGC-QXVCC-GKH8K-4KR66
	QFV8K-HXZBM-CM6R3-RBRC7-PDY2J
	QQBV8-GCGMC-7CHW3-3F7MF-TC878
	RC7JH-VTKHG-RVKWJ-HBC3T-FWGBG
	RKKGW-HP6FF-MFYJ6-TWRXM-44MQ6
	RP7VY-TJBCW-23P74-H47H9-7YFFG
	RRXHR-YPKQV-FD3R8-PTYMW-6PD7G
	RXM9G-J9BP8-GHPPC-YBMT3-3R2V6
	T3FCY-QQMK2-4G84G-DV4X8-MYDCT
	T98GF-R6C7Y-3MCV2-7C9DK-VC2F8
	TFYX7-9GG6R-PHK2H-TBR44-T6Q79
	TJKTG-TFVPY-YK87C-8TJVV-BKRFV
	TMVB4-VWDDT-QHTG2-4YQDB-FK9F6
	V3Y3C-CM9GR-QP74P-32V4C-6J3B6
	V68HD-MBT4W-FFW2B-2WBQP-7HDDG
	VCVG6-QK649-M49F8-DC8CG-D7FCT
	VD4WG-Y998T-3MGWX-GPW2Q-3QVC8
	VFJMK-P9XMW-4KYXP-RVV89-Q7J3J
	VH3C6-PXVPY-72M79-V7V3B-VRFJ6
	VTVD9-VHJFG-GC376-QHRJM-YY6PG
	VWXJ3-Y7K39-HPVQM-QG3XP-W3GBG
	VX8MR-Q3JK3-WWTT4-D8CRX-4FW6T
	VYPK3-6V2M9-XM76K-HJ7P9-3BMBJ
	W3TGH-738CC-JBT88-PTHD8-F4CQG
	W7XTC-2YWFB-K6BPT-GMHMV-B6FDY
	WGQMC-MC423-7T8MK-FYFTY-T9JQJ
	WJYPQ-7Q696-KRPG7-K2XHT-YKV4T
	WM6CV-TGGK8-4BGT2-3XX76-WFRDW
	WMJ24-P4GVG-B4BXF-DX4GR-VM9QT
	WTXM7-QD98Y-2R7J6-YWZPB-WJP9T
	XPMBG-V4QT4-9YPDB-TKK4K-RWP8G
	XQ2BG-77BPV-7B3B9-HBMVR-XC8P6
	OEM:
	DKRBQ-TXYCX-6K4GD-4CPJ7-C6B26
	F2WQC-WTPDW-TC9QC-RKPTB-PKHRT
	FT9CH-XVXW7-7BFCM-RPR49-VDHYD
	M4G3G-77CGM-9FY8T-PMWBC-JJYDM
	MYQKG-6P9CP-B6F94-CDMGG-7TJGD
	PW3DW-PC9D8-Q7VMQ-8YTMY-RTR9G
	TBXVP-MB6YG-MH8W4-VXGW2-QYB9W
	WWWFW-87P76-HP96R-BP9M6-6PJQW
	Plus! 98:
	411-2781863
	450-0535503


	 
	Windows ME
	MEDIA SET CD Windows Millennium EdtnEnglish FPP NFD: K9KKF-3M2XD-HQR3R-GB6BQ-4YBJJ
	MEDIA SET CD Windows Millennium EdtnEnglish FPP NFD: P88DY-KT78Q-V6C23-4RFVR-QYKPB
	CCP BYPASS ProdKey3 Windows Syst 00028 CCP Rtl: R4BKD-7CQQQ-KHPHT-DCHK2-2HHH2
	CCP BYPASS ProdKey3 Windows Syst 00028 CCP Rtl: TB69R-2XWHH-GVKH8-YPM27-63VVK
	Base Lbl Stock PCPgBk NLPT PID 3 GrpID029 [3M] (OEM): WPHDD-QQKMV-DVKQQ-T6HBB-CGFDQ
	Base Lbl Stock PCPgBk NLPT PID 3 GrpID029 [3M] (OEM): JPB79-G7TJC-99BFY-RDQCY-MJ4DT


	B88DH-VQ89B-G4WWK-DCBP2-7B7PW
	FMMMC-G8GQH-BH9MT-YBRH3-CRD6T
	HBTD9-6P338-XT2MV-QBTTF-WPGGB
	J7C6X-QC2BH-GGX24-7FQG7-2K398
	KKK3F-QKXGY-WHG99-B92WK-GFK4C
	P8DJW-RQXXM-T8JCW-HFB29-4FK3Y


	 
	Windows 2000

	T3KB9-4KCJF-D3H36-TDR47-RMMWK

	MEDIA SET CD Windows Pro 2000 English FPP (A): WMCVC-CD8D9-PB93H-TW8KQ-D42QY
	SubAssy Windows Svr 2000 English INTEL VUP NFD: BCHQB-PMWJ3-CQRQC-GX7BT-RDFCP
	Base Lbl Stock ROY PID 3 GrpID 019 PCCOA[3M]: JYTQH-KFCRD-8MQRT-XG9CM-FF63Y
	Microsoft Windows 2000 ADVANCED SERVER S/N: RM233-2PRQQ-FR4RH-JP89H-46QYB
	Microsoft Windows 2000 PROFESSIONAL WITH SP1: DDTPV-TXMX7-BBGJ9-WGY8K-B9GHM
	Microsoft Windows 2000 Server Resource Kit CD-KEY: TCJC7-H2QDH-3T7G7-R6RTM-YRK3Y
	Windows 2000 Advanced Server: H6TWQ-TQQM8-HXJYG-D69F7-R84VM
	 
	Windows XP

	FCKGW-RHQQ2-YXRKT-8TG6W-2B7Q8

	(jason’s): FQDRR-PYVJR-BT7B6-XV6TX-2CXKY
	(donnie’s): B6RH8-Q78RJ-76G6V-V96G4-Q8634
	(mom’s): F6XBR-HBWVH-6B93M-YMK4B-F6792
	(peter’s): XG7P2-FWHWC-QXJTM-9XQHK-V2HYH


	BJXGH-4TG7P-F9PRP-K6FJD-JQMPM
	DTWB2-VX8WY-FG8R3-X696T-66Y46
	DW3CF-D7KYR-KMR6C-3X7FX-T8CVM
	DW87C-76RXP-LLK6C-3FJ2J-2908F
	F6PGG-4YYDJ-3FF3T-R328P-3BXTG
	FM9FY-TMF7Q-KCKCT-V9T29-TBBBG
	JJWKH-7M9R8-26VM4-FX8CC-GDPD8
	KWT78-4D939-MRKK9-64W8C-CPF33
	MQPD6-C748R-FMRV6-8C3QK-79THJ
	Q3R8Y-MP9KD-3M6KB-383YB-7PK9Q
	QB2BW-8PJ2D-9X7JK-BCCRT-D233Y
	RBDC9-VTRC8-D7972-J97JY-PRVMG
	RK7J8-2PGYQ-4P7VL-V6PMB-F6XPQ


	 
	Office 97
	MEDIA SET CD Office 97 W32 English SR2 NFD COM (A): 9001-9353861
	MEDIA SET CD Office 97 W32 English SR2 NFD COM: 9001-9353877
	4667-0009847
	8068-2570043
	 
	Office 2000

	WQCW8-6YWF9-TDW73-697YX-CJH3Y

	ProdKey3 Office Pallet 00004 CCP Rtl: T3KB9-4KCJF-D3H36-TDR47-RMMWK
	CCP BYPASS ProdKey3 Office Pallet 00004: K4WKC-684BB-4DBDR-8DYK9-M2XFW
	MEDIA SET CD Office 2000 W32 English ORW SR1a: P2QQ9-P6HY3-DCVMK-T4B9D-27PDJ
	MEDIA SET CD Office 2000 W32 English ORW NFD SR1a: TF4BF-TVJ2H-676YY-G39DF-9FDH3
	MEDIA SET CD Office 2000 W32 English: CPF2R-BM9YX-T2P9X-P66Q4-6GXGJ
	MEDIA SET CD Office 2000 W32 English: VCBKG-K2DYJ-Q3PYH-R42WD-CTX63
	Office 2000 Pro: MWF64-MCDW6-46M9J-PDHT4-TJCWM
	Office 2000 Pro: P7HJX-RX7F9-W9FGK-T9HMF-8XT9J
	Office 2000: DT3FT-BFH4M-GYYH8-PG9C3-8K2FJ


	BGF6V-R7323-2CKHJ-R37XF-T9BFT
	BTB66-3JBDP-KJ67Q-G2CMR-7JMDX
	C4WTV-DDC3W-PJGGY-F89JF-CDPEQ
	CR8T7-73P4F-CGJ23-643PD-P42J3
	D6TQ7-QQP6T-8KC77-9443D-X443D
	DG62H-2WG9B-CW742-TB23R-PMXGK
	DR674-KJWQW-HGQKT-WGDBG-4RKY3
	DT3FT-BFH4M-GYYH8-PG9C3-8K2FJ
	G9J8H-JHWTT-JVJMC-TBHX6-848JJ
	GC6J3-GTQ62-FP876-94FBR-D3DX8
	GGX2P-DXCCP-443R8-4KBYV-BP3JM
	H4GW2-2M9C4-R8YWX-BYJFT-KKFQ3
	H4K33-2TQ93-3CG2D-KC99J-GG8BJ
	JJR2W-MVXMB-8DCM9-YTVXD-JR7GV
	KHQ6G-PRV7X-BWMQB-4G6XX-Y9YVX
	KXKJR-F3VWC-D2DGM-8B4CV-G26D8
	KXT79-Q89KQ-8GQCB-CXW9F-KDGTV
	M394M-6YKX4-FWCFV-PFHBY-2MW3F
	MWD3K-GCY28-9CWCB-Q7FBC-T9D44
	PHDMT-HFWC4-MB6RW-GV86P-GBFG3
	PTFJ6-78B62-V2F4Q-DGK2M-239P3
	QGTJ6-F4CHG-DGRTC-GDJCM-38T9V
	QP3X2-T7Y8Q-8X2VR-PQCTP-YQCYQ
	R33D2-VC8W7-26YKH-B3J7G-YR9QJ
	V49KK-XTFJY-4D837-DX8VG-PTCBT
	V4QC6-4JJJ3-VDHJX-K7BYV-447MC
	V7PTP-H2V4H-XHRTJ-V9FFB-K9GBJ
	W8R49-CGX29-F9FGC-PG3RY-Q7MDV
	WPB69-HRK28-WYRJ9-FKK76-DGDC8
	XCMPK-42J9C-Q8DQK-8W49R-TB9FJ
	XDDT9-9T82Y-47WDW-B9TV4-8M9MD
	XFKVX-YF7PF-DKRFW-VJM38-FMF38
	XMT8F-287Y4-XCD6C-YG3MG-C86TR


	 
	Office XP
	Microsoft Office XP PRO V10.2627.2625 RTM: FM9FY-TMF7Q-KCKCT-V9T29-TBBBG
	CCP BYPASS ProdKey3 Office Apps 2002 00032 PrdActive: P3TJ7-4P6MP-7BPDD-6V67F-9FM8Q
	 
	Works Suite 2000
	Works 2000 Win32 English ORY OEI CD: 03002-OEM-0009165-69210
	Works Ste 2000 Win32 English NA ORY OEI CD Rls2: VRC93-3DQ7M-P7JBJ-WT3QM-7F83G
	Works Ste 2000 Win32 English NA ORY OEI CD Rls2: XKW2G-YJJ2F-3PTRX-3BG28-R938T
	 
	Works Suite 2001
	Works Ste 2001 Win32 English NA ORY OEI CD: MVCBQ-QF2RK-CM342-FYJBF-H4VB6
	MEDIA SET CD Works Ste 2001 W32English NFD: TVTXP-R2XVC-K29RR-TQ8K8-6DJ9T
	Base Lbl Stock PID 3 GrpID 005 SACOA[DeLaRue]: XQ3PW-9D99G-984CC-M6JR2-QKYJB
	SubAssy Works Ste 2001 W32 English NFD PID: M9PFC-T4WP9-J39YP-DDPGW-TGX68
	 
	Works Suite 2002
	MEDIA SET CD Works Ste 2002 W32English ProdAct: H7MVT-K7FDQ-8HMPR-H7XPF-CBWKD
	Base Lbl Stock PID 3 GrpID 033 SACOA[DeLaRue]: JMGVQ-WQ72Q-JV6Q7-3WKGX-M7H9D
	 
	MS MISC
	Office Pro for Win95: 425-1921701
	Office Pro v4.2 for Windows: 14080-000-4203561
	Office Pro v4.3c for Windows: 28779-051-0101444
	Office 10 Retail - Full Package Product: B9GJW-TB7BW-CBRPB-CC887-C8833
	MEDIA SET CD Publisher 2002 W32 English NA ProdAct FPP: BRMQP-V8HFF-KKXWF-HKRQ6-FDGVM
	Access 97: 9001-9346337
	Excel 97: 9001-9346346
	Word 97: 9001-9346355
	 
	MISC


	Adobe Acrobat 5
	KWW500R7150122-128
	 
	Adobe Photoshop 6.0
	PWW600R7105467-948
	 
	CuteFTP 5.0 XP
	AT9K9M9C4JXFXF
	 
	DVD Copy Plus 5.5.10.15
	5502-0627-8358-7019-9607-5485
	DVD Copy Plus V.4 Power CD-R Serial: 58A0N-CRSD@-529X0-VW425-5@APC
	 
	Music Match Jukebox
	GKJWU-RGK9K-974R5-9L74R
	 
	Norton 2003
	2124-4457-4421-202a
	 
	Norton Ghost 6.0
	1234123412341234
	 
	NERO
	1500-0001-0092-0227-9281-4716
	1502-1000-0154-0335-2342-2811
	1503-4630-7995-1402-6114-2213
	1503-0947-6845-2627-4181-1200
	1504-2382-7940-2542-4287-2889
	1507-2125-4668-3804-2182-8975
	1507-0604-2736-0574-5444-4821
	5505-0123-2260-3333-4444-9022
	150026-061990-203664-551403
	150252-032521-412561-933307
	150294-071592-104896-250899
	 
	Power DVD 4 Deluxe
	DX32812592653746
	DX96742126897829
	MV10000000000414
	 
	Real Jukebox 2
	352-77191-4669
	 
	Real Player 8 Plus
	0444-90-4466
	0288-35-9466
	 
	Roxio Easy CD & DVD Creator 6.0
	34BBX-PYCRJ-WDXQ3-VTQ4J-HGJ22
	3BHQX-KQC6Q-2J2R3-FVRDG-TDXHH
	8XPDH-PCKKG-6MPKT-FTM67-2FMWG
	BD-JWZS4-QX3MR-0241L
	BTY8F-D3HRR-PJJGR-CJ8GJ-VXQHG
	DWX67-DD8M8-273RP-QMBVC-DT462
	MHQXH-V7V2F-VYMH2-W36CM-9KRKM
	TGTGW-WXFKK-BW6VM-GHWKQ-VDPKY
	Y4VP6-BRXHM-J68D7-3FFJD-7GWV	
					'''
					noMore1 = input("Press [ENTER] key to exit the product key generator")