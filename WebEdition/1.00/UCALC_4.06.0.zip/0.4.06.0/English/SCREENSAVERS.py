			if screensaverSelect == ("1"):
				scron = int(1)
				scrcount = int(0)
				while scron == 1:
					print ("Unavailable")
			if screensaverSelect == ("2"):
				scron = int(1)
				scrcount = int(0)
				while scron == 1:
					print ("Unavailable")
			if screensaverSelect == ("3"):
				scron = int(1)
				scrcount = int(0)
				while scron == 1:
					print ("Unavailable")
			if screensaverSelect == ("4"):
				scron = int(1)
				scrcount = int(0)
				while scron == 1:
					print ("X      X    Y      Y")
					print ("X      X    Y      Y")
					print ("XXXXXXXX    YYYYYYYY")
					print (" X    X      Y    Y ")
					print (" X    X      Y    Y ")
					print (" XXXXXX      YYYYYY ")
					print ("  X  X        Y  Y  ")
					print ("  X  X        Y  Y  ")
					print ("  XXXX        YYYY  ")
					print ("   XX          YY   ")
					print ("   XX          YY   ")
					print ("   XX          YY   ")
					print ("  XXXX        YYYY  ")
					print ("  X  X        Y  Y  ")
					print ("  X  X        Y  Y  ")
					print (" XXXXXX      YYYYYY ")
					print (" X    X      Y    Y ")
					print (" X    X      Y    Y ")
					print ("XXXXXXXX    YYYYYYYY")
					print ("X      X    Y      Y")
					print ("X      X    Y      Y")
					scrcount += 21
			if screensaverSelect == ("5"):
				scron = int(1)
				scrcount = int(0)
				while scron == 1:
					print ("Unavailable")