		if calcIDSes == 36:
					print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
					print ("Greater than calculator")
					isItGreater1 = int(input("Enter the first number: "))
					isItGreater2 = int(input("Enter the second number: "))
					if (isItGreater1 > isItGreater2):
						curanswer = isItGreater1
						lessThan = isItGreater2
					if (isItGreater1 < isItGreater2):
						curanswer = isItGreater2
						lessThan = isItGreater1
					print (str(curanswer) + " is greater than " + str(lessThan))
					bloat1 = input("| FAIL! SETUP RESTARTING (we can't fix the bug right now, we are porting features in. Stabilizing later, my bad)")