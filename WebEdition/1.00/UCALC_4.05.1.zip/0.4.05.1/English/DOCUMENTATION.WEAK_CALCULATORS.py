WikIDSelect = int(20001)
if WikIDSelect == 20001:
	if WikIDSelect == 20001:
		if WikIDSelect == 20001:
			if WikIDSelect == 20001:
				print ("Weak calculators")
				print ("| Please read 'Processor setup' first if you haven't already")
				print ("A weak calculator with uCalc is considered a calculator that")
				print ("Can't calculate high amounts of numbers")
				print ("Any calculator below 32 bit here is considered weak, as it can't do advanced calculations")
				print ("But then why did we include them? UCalc supports all types of math. If you would like to experience simple calculators, and what")
				print ("the worlds weakest calculator feels like, go ahead! If you would like to experience what the worlds most advanced calculator feels like")
				print ("be my guest! All numbers are allowed. No exceptions")