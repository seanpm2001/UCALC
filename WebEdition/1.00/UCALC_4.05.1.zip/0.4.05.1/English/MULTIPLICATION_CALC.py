		if calcIDSes == 14:
					print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
					print ("Multiply")
					multiply1 = int(input("Enter first number to multiply: "))
					multiply2 = int(input("Enter second number to multiply: "))
					curanswer = (multiply1 * multiply2)
					print ("\n\nThe answer is: " + str(curanswer)) 
					bloat1 = input("| FAIL! SETUP RESTARTING (we can't fix the bug right now, we are porting features in. Stabilizing later, my bad)")