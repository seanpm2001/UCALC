enterToEnter = input("Press [ENTER] key to start! ")
chatID = int(4)
if (chatID == 4):
	print ("You are now talking with Albert Einstein")
	print ("|--------|")
	print ("This is the start of our conversation! Try to say a greeting")
	print ("Albert Einstein > Hello there! ")
	loopforever3 = int(1)
	while (loopforever3 == 1):
		console1 = str(input("You > "))
		if (console1 == "happy man" or console1 == "Happy man" or console1 == "Happy Man" or console1 == "HAPPY MAN"):
			print ("Albert Einstein > Un homme heureux est trop content du présent pour trop se soucier de l'avenir.")
			print ("\n{Translation} A happy man is too satisfied with the present to dwell too much on the future.")
		if (console1 == "authority" or console1 == "Authority" or console1 == "AUTHORITY"):
			print ("Albert Einstein > Autoritätsdusel ist der größte Feind der Wahrheit.")
			print ("\n{Translation} Unthinking respect for authority is the greatest enemy of truth.")
		if (console1 == "enemy" or console1 == "Enemy" or console1 == "ENEMY"):
			print ("Albert Einstein > Lieber Habicht! / Es herrscht ein weihevolles Stillschweigen zwischen uns, so daß es mir fast wie eine sündige Entweihung vorkommt, ")
			print ("wenn ich es jetzt durch ein wenig bedeutsames Gepappel unterbreche... / Was machen Sie denn, Sie eingefrorener Walfisch, Sie getrocknetes, eingebüchstes")
			print ("Stück Seele...?")
			print ("\n{Translation} Dear Habicht, / Such a solemn air of silence has descended between us that I almost feel as if I am committing a sacrilege when I break")
			print ("it now with some inconsequential babble... / What are you up to, you frozen whale, you smoked, dried, canned piece of soul...?")
		if (console1 == "body" or console1 == "Body" or console1 == "BODY"):
			print ("Albert Einstein > Ist die Trägheit eines Körpers von seinem Energieinhalt abhängig? ")
			print ("\n{Translation} Does the inertia of a body depend upon its energy content?")
		if (console1 == "lion" or console1 == "Lion" or console1 == "LION"):
			print ("Albert Einstein > Die Natur zeigt uns vom Löwen zwar nur den Schwanz. Aber es ist mir unzweifelhaft, dass der Löwe dazugehört, wenn er sich auch wegen ")
			print ("seiner ungeheuren Dimensionen dem Blicke nicht unmittelbar offenbaren kann. Wir sehen ihn nur wie eine Laus, die auf ihm sitzt.")
			print ("\n{Translation} Nature shows us only the tail of the lion. But there is no doubt in my mind that the lion belongs with it even if he cannot reveal ")
			print ("himself to the eye all at once because of his huge dimension. We see him only the way a louse sitting upon him would.")
		if (console1 == "epoch" or console1 == "Epoch" or console1 == "EPOCH"):
			print ("Albert Einstein > Man begreift schwer beim Erleben dieser ''großen Zeit'', daß man dieser verrückten, verkommenen Spezies angehört, die sich ")
			print ("Willensfreiheit zuschreibt. Wenn es doch irgendwo eine Insel der Wohlwollenden und Besonnenen gäbe! Da wollte ich auch glühender Patriot sein.")
			print ("\n{Translation} In living through this ''great epoch,'' it is difficult to reconcile oneself to the fact that one belongs to that mad, degenerate ")
			print ("species that boasts of its free will. How I wish that somewhere there existed an island for those who are wise and of good will! In such a place even ")
			print ("I should be an ardent patriot!")
		if (console1 == "retract" or console1 == "Retract" or console1 == "RETRACT"):
			print ("Albert Einstein > Es ist bequem mit dem Einstein. Jedes Jahr widerruft er, was er das vorige Jahr geschrieben hat.")
			print ("\n{Translation} It's convenient with that fellow Einstein, every year he retracts what he wrote the year before.")
		if (console1 == "game" or console1 == "Game" or console1 == "GAME" or console1 == "idle" or console1 == "Idle" or console1 == "IDLE" or console1 == "idle game" or console1 == "Idle game" or console1 == "Idle Game" or console1 == "idle Game" or console1 == "IDLE game" or console1 == "IDLE Game" or console1 == "IDLE GAME"):
			print ("Albert Einstein > Begriffe, welche sich bei der Ordnung der Dinge als nützlich erwiesen haben, erlangen über uns leicht eine solche Autorität, ")
			print ("dass wir ihres irdischen Ursprungs vergessen und sie als unabänderliche Gegebenheiten hinnehmen.] Thus they might come to be stamped as ")
			print ("''necessities of thought,'' ''a priori givens,'' etc. The path of scientific progress is often made impassable for a long time by such errors. ")
			print ("[Der Weg des wissenschaftlichen Fortschritts wird durch solche Irrtümer oft für längere Zeit ungangbar gemacht.")
			print ("\n{Translation} Therefore it is by no means an idle game if we become practiced in analysing long-held commonplace concepts and showing the ")
			print ("circumstances on which their justification and usefulness depend, and how they have grown up, individually, out of the givens of experience. ")
			print ("Thus their excessive authority will be broken. They will be removed if they cannot be properly legitimated, corrected if their correlation with") 
			print ("given things be far too superfluous, or replaced if a new system can be established that we prefer for whatever reason. ")
		if (console1 == "technology" or console1 == "Technology" or console1 == "TECHNOLOGY"):
			print ("Albert Einstein > Unser ganzer gepriesener Fortschritt der Technik, überhaupt die Civilisation, ist der Axt in der Hand des pathologischen ")
			print ("Verbrechers vergleichbar.")
			print ("\n{Translation} Our entire much-praised technological progress, and civilization generally, could be compared to an axe in the hand of a ")
			print ("pathological criminal.")
		if (console1 == "pram" or console1 == "Pram" or console1 == "PRAM"):
			print ("Albert Einstein > Ich habe auch manchen wissenschaftlichen Plan überlegt, während ich Dich im Kinderwagen spazieren schob!")
			print ("\n{Translation} I have also considered many scientific plans during my pushing you around in your pram!")
		if (console1 == "grow up" or console1 == "Grow up" or console1 == "Grow Up" or console1 == "GROW UP" or console1 == "healthy" or console1 == "Healthy" or console1 == "HEALTHY"):
			print ("Albert Einstein > Geh recht viel spazieren, dass Du recht gesund wirst und lies nicht gar zu viel sondern spar Dir noch was auf bis Du gross bist.")
			print ("\n{Translation} Make a lot of walks to get healthy and don’t read that much but save yourself some until you’re grown up.")
		if (console1 == "mom" or console1 == "Mom" or console1 == "MoM" or console1 == "MOM" or console1 == "mother" or console1 == "Mother" or console1 == "MOTHER"):
			print ("Albert Einstein > Liebe Mutter! Heute eine freudige Nachricht. H. A. Lorentz hat mir telegraphiert, dass die englischen Expeditionen die ")
			print ("Lichtablenkung an der Sonne wirklich bewiesen haben.")
			print ("\n{Translation} Dear mother! Today a joyful notice. H. A. Lorentz has telegraphed me that the English expeditions have really proven the deflection ")
			print ("of light at the sun.")
		if (console1 == "jew" or console1 == "Jew" or console1 == "JEW" or console1 == "jewish" or console1 == "Jewish" or console1 == "JEWISH" or console1 == "swiss jew" or console1 == "Swiss jew" or console1 == "Swiss Jew" or console1 == "SWISS JEW"):
			print ("Albert Einstein > Noch eine Art Anwendung des Relativitätsprinzips zum Ergötzen des Lesers: Heute werde ich in Deutschland als ")
			print ("''deutscher Gelehrter'', in England als ''Schweizer Jude'' bezeichnet; sollte ich aber einst in die Lage kommen, als ''bète noire'' ")
			print ("präsentiert zu werden, dann wäre ich umgekehrt für die Deutschen ein Schweizer Jude'', für die Engländer ein ''deutscher Gelehrter''.")
			print ("\n{Translation} By an application of the theory of relativity to the taste of readers, today in Germany I am called a German man of ")
			print ("science, and in England I am represented as a Swiss Jew. If I come to be represented as a bête noire, the descriptions will be reversed, ")
			print ("and I shall become a Swiss Jew for the Germans and a German man of science for the English!")
		if (console1 == "" or console1 == " " or console1 == "  " or console1 == "   "):
			print ("Albert Einstein > Please type something! Don't leave it blank")
		if (console1 == "poem" or console1 == "Poem" or console1 == "POEM"):
			print ("Albert Einstein > Mehr als ich mit Worten sagen kann.")
			print ("Doch fürcht' ich, dass er bleibt allein")
			print ("Mit seinem strahlenden Heiligenschein.")
			print (" ")
			print ("{Translation} ")
			print ("How much do I love that noble man")
			print ("More than I could tell with words")
			print ("I fear though he'll remain alone")
			print ("With a holy halo of his own.")
		if (console1 == "fairer" or console1 == "Fairer" or console1 == "FAIRER"):
			print ("Albert Einstein > Es ist das schönste Los einer physikalischen Theorie, wenn sie selbst zur Aufstellung einer umfassenden Theorie den Weg weist, ")
			print ("in welcher sie als Grenzfall weiterlebt.")
			print ("\n{Translation}No fairer destiny could be allotted to any physical theory, than that it should of itself point out the way to the introduction of a")
			print ("more comprehensive theory, in which it lives on as a limiting case.")
		if (console1 == "lord" or console1 == "Lord" or console1 == "LORD"):
			print ("Albert Einstein > Raffiniert ist der Herrgott, aber boshaft ist er nicht.")
			print ("\n{Translation} Subtle is the Lord, but malicious He is not.")
		if (console1 == "reality" or console1 == "Reality" or console1 == "REALITY"):
			print ("Albert Einstein > Insofern sich die Sätze der Mathematik auf die Wirklichkeit beziehen, sind sie ")
			print ("nicht sicher, und insofern sie sicher sind, beziehen sie sich nicht auf die Wirklichkeit.")
			print ("\n{Translation} In so far as theories of mathematics speak about reality, they are not certain, ")
			print ("and in so far as they are certain, they do not speak about reality.")
		if (console1 == "dice" or console1 == "Dice" or console1 == "DICE"):
			print ("Albert Einstein > Die Quantenmechanik ist sehr achtung-gebietend. Aber eine innere Stimme sagt mir, ")
			print ("daß das doch nicht der wahre Jakob ist. Die Theorie liefert viel, aber dem Geheimnis des Alten bringt ")
			print ("sie uns kaum näher. Jedenfalls bin ich überzeugt, daß der nicht würfelt.")
			print ("\n{Translation} Quantum mechanics is certainly imposing. But an inner voice tells me that it is not")
			print ("yet the real thing. The theory says a lot, but does not really bring us any closer to the secret of ")
			print ("the ''old one.'' I, at any rate, am convinced that He does not throw dice.")
		if (console1 == "fate" or console1 == "Fate" or console1 == "FATE"):
			print ("Albert Einstein > Ich glaube an Spinozas Gott, der sich in der gesetzlichen Harmonie des Seienden ")
			print ("offenbart, nicht an einen Gott, der sich mit Schicksalen und Handlungen der Menschen abgibt.")
			print ("\n{Translation} I believe in Spinoza's God, Who reveals Himself in the lawful harmony of the world, ")
			print ("not in a God Who concerns Himself with the fate and the doings of mankind.")
		if (console1 == "stupid" or console1 == "Stupid" or console1 == "STUPID"):
			print ("Albert Einstein > If A is success in life, then A = x + y + z. Work is x, play is y and z is keeping your mouth shut.")
		if (console1 == "4D"):
			print ("Albert Einstein > No man can visualize four dimensions, except mathematically … I think in four dimensions, but only abstractly. The human mind can picture these dimensions no more than it can envisage electricity. Nevertheless, they are no less real than electro-magnetism, the force which controls our universe, within, and by which we have our being.")
		if (console1 == "money" or console1 == "Money" or console1 == "MONEY"):
			print ("Albert Einstein > I refuse to make money out of my science. My laurel is not for sale like so many bales of cotton.")
		if (console1 == "music" or console1 == "Music" or console1 == "MUSIC")
			print ("Albert Einstein > If I were not a physicist, I would probably be a musician. I often think in music. I live my daydreams in music. I see my life in terms of music. I cannot tell if I would have done any creative work of importance in music, but I do know that I get most joy in life out of my violin.")
		if (console1 == "read" or console1 == "Read" or console1 == "READ"):
			print ("Albert Einstein > Reading after a certain age diverts the mind too much from its creative pursuits. Any man who reads too much and uses his own brain too little falls into lazy habits of thinking, just as the man who spends too much time in the theater is tempted to be content with living vicariously instead of living his own life.")
		if (console1 == "gothic" or console1 == "Gothic" or console1 == "GOTHIC"):
			print ("Albert Einstein > Our time is Gothic in its spirit. Unlike the Renaissance, it is not dominated by a few outstanding personalities. The twentieth century has established the democracy of the intellect. In the republic of art and science there are many men who take an equally important part in the intellectual movements of our age. It is the epoch rather than the individual that is important. There is no one dominant personality like Galileo or Newton. Even in the nineteenth century there were still a few giants who outtopped all others. Today the general level is much higher than ever before in the history of the world, but there are few men whose stature immediately sets them apart from all others.")
		if (console1 == "america" or console1 == "America" or console1 == "AMERICA" or console1 == "usa" or console1 == "Usa" or console1 == "USa" or console1 == "USA"):
			print ("Albert Einstein > In America, more than anywhere else, the individual is lost in the achievements of the many. America is beginning to be the world leader in scientific investigation. American scholarship is both patient and inspiring. The Americans show an unselfish devotion to science, which is the very opposite of the conventional European view of your countrymen. Too many of us look upon Americans as dollar chasers. This is a cruel libel, even if it is reiterated thoughtlessly by the Americans themselves. It is not true that the dollar is an American fetish. The American student is not interested in dollars, not even in success as such, but in his task, the object of the search. It is his painstaking application to the study of the infinitely little and the infinitely large which accounts for his success in astronomy.")
		if (console1 == "material" or console1 == "Material" or console1 == "MATERIAL"):
			print ("Albert Einstein > We are inclined to overemphasize the material influences in history. The Russians especially make this mistake. Intellectual values and ethnic influences, tradition and emotional factors are equally important. If this were not the case, Europe would today be a federated state, not a madhouse of nationalism.")
		if (console1 == "determine" or console1 == "Determine" or console1 == "DETERMINE"):
			print ("Albert Einstein > I am a determinist. As such, I do not believe in free will. The Jews believe in free will. They believe that man shapes his own life. I reject that doctrine philosophically. In that respect I am not a Jew.")
		if (console1 == "we can" or console1 == "We can" or console1 == "We Can" or console1 == "WE can" or console1 == "WE Can" or console1 == "WE CAN"):
			print ("Albert Einstein > I believe with Schopenhauer: We can do what we wish, but we can only wish what we must. Practically, I am, nevertheless, compelled to act as if freedom of the will existed. If I wish to live in a civilized community, I must act as if man is a responsible being. I know that philosophically a murderer is not responsible for his crime; nevertheless, I must protect myself from unpleasant contacts. I may consider him guiltless, but I prefer not to take tea with him.")
		if (console1 == "career" or console1 == "Career" or console1 == "CAREER"):
			print ("Albert Einstein > My own career was undoubtedly determined, not by my own will but by various factors over which I have no control—primarily those mysterious glands in which Nature prepares the very essence of life, our internal secretions.")
		if (console1 == "psychic" or console1 == "Psychic" or console1 == "PSYCHIC"):
			print ("Albert Einstein > Whereas materialistic historians and philosophers neglect psychic realities, Freud is inclined to overstress their importance. I am not a psychologist, but it seems to me fairly evident that physiological factors, especially our endocrines, control our destiny … I am not able to venture a judgment on so important a phase of modern thought. However, it seems to me that psychoanalysis is not always salutary. It may not always be helpful to delve into the subconscious. The machinery of our legs is controlled by a hundred different muscles. Do you think it would help us to walk if we analyzed our legs and knew exactly which one of the little muscles must be employed in locomotion and the order in which they work? … I am not prepared to accept all his [Freud's] conclusions, but I consider his work an immensely valuable contribution to the science of human behavior. I think he is even greater as a writer than as a psychologist. Freud's brilliant style is unsurpassed by anyone since Schopenhauer.")
		if (console1 == "progress" or console1 == "Progress" or console1 == "PROGRESS"):
			print ("Albert Einstein > The only progress I can see is progress in organization. The ordinary human being does not live long enough to draw any substantial benefit from his own experience. And no one, it seems, can benefit by the experiences of others. Being both a father and teacher, I know we can teach our children nothing. We can transmit to them neither our knowledge of life nor of mathematics. Each must learn its lesson anew.")
		if (console1 == "inspire" or console1 == "Inspire" or console1 == "INSPIRE"):
			print ("Albert Einstein > I believe in intuitions and inspirations. I sometimes feel that I am right. I do not know that I am. When two expeditions of scientists, financed by the Royal Academy, went forth to test my theory of relativity, I was convinced that their conclusions would tally with my hypothesis. I was not surprised when the eclipse of May 29, 1919, confirmed my intuitions. I would have been surprised if I had been wrong.")
		if (console1 == "imagine" or console1 == "Imagine" or console1 == "IMAGINE"):
			print ("Albert Einstein > I am enough of an artist to draw freely upon my imagination. Imagination is more important than knowledge. Knowledge is limited. Imagination encircles the world.")
		if (console1 == "child" or console1 == "Child" or console1 == "CHILD"):
			print ("Albert Einstein > As a child, I received instruction both in the Bible and in the Talmud. I am a Jew, but I am enthralled by the luminous figure of the Nazarene.")
		if (console1 == "jesus" or console1 == "Jesus" or console1 == "JESUS"):
			print ("Albert Einstein > Jesus is too colossal for the pen of phrasemongers, however artful. No man can dispose of Christianity with a bon mot.")
		if (console1 == "presence" or console1 == "Presence" or console1 == "PRESENCE"):
			print ("Albert Einstein > No one can read the Gospels without feeling the actual presence of Jesus. His personality pulsates in every word. No myth is filled with such life.")
		if (console1 == "nationalism" or console1 == "Nationalism" or console1 == "NATIONALISM"):
			print ("Albert Einstein > It is quite possible to be both. I look upon myself as a man. Nationalism is an infantile disease. It is the measles of mankind.")
		if (console1 == "adaptable" or console1 == "Adaptable" or console1 == "ADAPTABLE" or console1 == "adapt" or console1 == "Adapt" or console1 == "ADAPT"):
			print ("Albert Einstein >  We Jews have been too adaptable. We have been too eager to sacrifice our idiosyncrasies for the sake of social conformity. … Even in modern civilization, the Jew is most happy if he remains a Jew.")
		if (console1 == "tradition" or console1 == "Tradition" or console1 == "TRADITION"):
			print ("Albert Einstein > I do not think that religion is the most important element. We are held together rather by a body of tradition, handed down from father to son, which the child imbibes with his mother's milk. The atmosphere of our infancy predetermines our idiosyncrasies and predilections.")
		if (console1 == "jewish question" or console1 == "Jewish question" or console1 == "Jewish Question" or console1 == "JEWISH QUESTION"):
			print ("Albert Einstein > But to return to the Jewish question. Other groups and nations cultivate their individual traditions. There is no reason why we should sacrifice ours. Standardization robs life of its spice. To deprive every ethnic group of its special traditions is to convert the world into a huge Ford plant. I believe in standardizing automobiles. I do not believe in standardizing human beings. Standardization is a great peril which threatens American culture.")
		if (console1 == "happy" or console1 == "Happy" or console1 == "HAPPY"):
			print ("Albert Einstein > I am happy because I want nothing from anyone. I do not care for money. Decorations, titles or distinctions mean nothing to me. I do not crave praise. The only thing that gives me pleasure, apart from my work, my violin and my sailboat, is the appreciation of my fellow workers.")
		if (console1 == "credit" or console1 == "Credit" or console1 == "CREDIT"):
			print ("Albert Einstein > I claim credit for nothing. Everything is determined, the beginning as well as the end, by forces over which we have no control. It is determined for the insect as well as for the star. Human beings, vegetables or cosmic dust, we all dance to a mysterious tune, intoned in the distance by an invisible player.")
		if (console1 == "atheist" or console1 == "Atheist" or console1 == "ATHEIST" or console1 == "atheism" or console1 == "Atheism" or console1 == "ATHEISM"):
			print ("Albert Einstein > I am not an Atheist. I do not know if I can define myself as a Pantheist. The problem involved is too vast for our limited minds. May I not reply with a parable? The human mind, no matter how highly trained, cannot grasp the universe. We are in the position of a little child, entering a huge library whose walls are covered to the ceiling with books in many different tongues. The child knows that someone must have written those books. It does not know who or how. It does not understand the languages in which they are written. The child notes a definite plan in the arrangement of the books, a mysterious order, which it does not comprehend, but only dimly suspects. That, it seems to me, is the attitude of the human mind, even the greatest and most cultured, toward God. We see a universe marvelously arranged, obeying certain laws, but we understand the laws only dimly. Our limited minds cannot grasp the mysterious force that sways the constellations. I am fascinated by Spinoza's Pantheism. I admire even more his contributions to modern thought. Spinoza is the greatest of modern philosophers, because he is the first philosopher who deals with the soul and the body as one, not as two separate things.")
		if (console1 == "pantheism" or console1 == "Pantheism" or console1 == "PANTHEISM"):
			print ("Albert Einstein > I am fascinated by Spinoza's pantheism, but I admire even more his contribution to modern thought because he is the first philosopher to deal with the soul and body as one, and not two separate things.")
		if (console1 == "bike" or console1 == "Bike" or console1 == "BIKE" or console1 == "bicycle" or console1 == "Bicycle" or console1 == "BICYCLE"):
			print ("Albert Einstein > Life is like riding a bicycle. To keep your balance you must keep moving.")
		if (console1 == "casualty" or console1 == "Casualty" or console1 == "CASUALTY"):
			print ("Albert Einstein > I believe that whatever we do or live for has its causality; it is good, however, that we cannot see through to it.")
		if (console1 == "good music" or console1 == "Good music" or console1 == "Good Music" or console1 == "GOOD MUSIC"):
			print ("Albert Einstein > The really good music, whether of the East or of the West, cannot be analyzed.")
		if (console1 == "future" or console1 == "Future" or console1 == "FUTURE"):
			print ("Albert Einstein > I never think of the future. It comes soon enough.")
		if (console1 == "vegetarian" or console1 == "Vegetarian" or console1 == "VEGETARIAN"):
			print ("Albert Einstein > Besides agreeing with the aims of vegetarianism for aesthetic and moral reasons, it is my view that a vegetarian manner of living by its purely physical effect on the human temperament would most beneficially influence the lot of mankind.")
		if (console1 == "dictator" or console1 == "Dictator" or console1 == "DICTATOR" or console1 == "DICTATE" or console1 == "dictate" or console1 == "Dictate"):
			print ("Albert Einstein > Die Diktatur bringt den Maulkorb und dieser die Stumpfheit. Wissenschaft kann nur gedeihen in einer ")
			print ("Atmosphäre des freien Wortes.")
			print ("\n{Translation} A dictatorship means muzzles all round and consequently stultification. Science can ")
			print ("flourish only in an atmosphere of free speech.")
		if (console1 == "external" or console1 == "External" or console1 == "EXTERNAL"):
			print ("Albert Einstein > Der Glaube an eine vom wahrnehmenden Subjekt unabhängige Außenwelt liegt aller Naturwissenschaft zugrunde.")
			print ("\n{Translation} The belief in an external world independent of the perceiving subject is the basis of ")
			print ("all natural science.")
		else:
			print ("Albert Einstein > I am not sure what you said. Please check your syntax and try again!")
noMore = input("Press [ENTER] key to end your conversation with Einstein ")