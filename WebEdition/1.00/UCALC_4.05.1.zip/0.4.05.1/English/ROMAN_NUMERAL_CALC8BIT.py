print (" ____  _____  __  __    __    _  _    _  _  __  __  __  __  ____  ____    __    __   ")
print ("(  _ \\(  _  )(  \\/  )  /__\\  ( \\( )  ( \\( )(  )(  )(  \\/  )( ___)(  _ \\  /__\\  (  )  ")
print (" )   / )(_)(  )    (  /(__)\\  )  (    )  (  )(__)(  )    (  )__)  )   / /(__)\\  )(__ ")
print ("(_)\\_)(_____)(_/\\/\\_)(__)(__)(_)\\_)  (_)\\_)(______)(_/\\/\\_)(____)(_)\\_)(__)(__)(____)")
print ("  ___    __    __    ___  __  __  __      __   ____  _____  ____        ")             
print (" / __)  /__\\  (  )  / __)(  )(  )(  )    /__\\ (_  _)(  _  )(  _ \\     ")               
print ("( (__  /(__)\\  )(__( (__  )(__)(  )(__  /(__)\\  )(   )(_)(  )   /   ")                 
print (" \\___)(__)(__)(____)\\___)(______)(____)(__)(__)(__) (_____)(_)\\_) ")                   
print ("\n\n")
tripToRome = str(input("Press [ENTER] key to starts"))
if (tripToRome == ""):
	if (tripToRome == ""):
		if (tripToRome == ""):
			calcIDSes = int(55)
			if (tripToRome == ""):
				print ("\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n")
				if calcIDSes == 55:
					print ("Roman numeral calculator")
					print ("NOTICE: this calculator is locked in 8 BIT MODE")
					getInputForRome1 = int(input("Enter a number to calculate: "))
					print ("Addition            [ID: 1]")
					print ("Subtraction         [ID: 2]")
					print ("Multiplication      [ID: 3]")
					print ("Division            [ID: 4]")
					print ("Modular division    [ID: 5]")
					getInputForRome2 = int(input("What type of calculation do you want to do out of the given options? Enter ID here: "))
					getInputForRome3 = int(input("Enter the second number to calculate"))
					if getInputForRome2 == 1:
						preRome = int(getInputForRome1 + getInputForRome3)
					if getInputForRome2 == 2:
						preRome = int(getInputForRome1 - getInputForRome3)
					if getInputForRome2 == 3:
						preRome = int(getInputForRome1 * getInputForRome3)	
					if getInputForRome2 == 4:
						preRome = int(getInputForRome1 / getInputForRome3)	
					if getInputForRome2 == 5:
						preRome = int(getInputForRome1 % getInputForRome3)	
					if preRome < 1:
						print ("Syntax error! The number you entered is too small to be transferred as a roman numeral")
					if preRome == 1:
						print ("The answer is I")
					if preRome == 2:
						print ("The answer is II")
					if preRome == 3:
						print ("The answer is III")
					if preRome == 4:
						print ("The answer is IV")
					if preRome == 5:
						print ("The answer is V")
					if preRome == 6:
						print ("The answer is VI")
					if preRome == 7:
						print ("The answer is VII")
					if preRome == 8:
						print ("The answer is VIII")
					if preRome == 9:
						print ("The answer is IX")
					if preRome == 10:
						print ("The answer is X")
					if preRome == 11:
						print ("The answer is XI")
					if preRome == 12:
						print ("The answer is XII")
					if preRome == 13:
						print ("The answer is XIII")
					if preRome == 14:
						print ("The answer is XIV")
					if preRome == 15:
						print ("The answer is XV")
					if preRome == 16:
						print ("The answer is XVI")
					if preRome == 17:
						print ("The answer is XVII")
					if preRome == 18:
						print ("The answer is XVIII")
					if preRome == 19:
						print ("The answer is XIX")
					if preRome == 20:
						print ("The answer is XX")
					if preRome == 21:
						print ("The answer is XXI")
					if preRome == 22:
						print ("The answer is XXII")
					if preRome == 23:
						print ("The answer is XXIII")
					if preRome == 24:
						print ("The answer is XXIV")
					if preRome == 25:
						print ("The answer is XXV")
					if preRome == 26:
						print ("The answer is XXVI")
					if preRome == 27:
						print ("The answer is XXVII")
					if preRome == 28:
						print ("The answer is XXVIII")
					if preRome == 29:
						print ("The answer is XXIX")
					if preRome == 30:
						print ("The answer is XXX")
					if preRome == 31:
						print ("The answer is XXXI")
					if preRome == 32:
						print ("The answer is XXXII")
					if preRome == 33:
						print ("The answer is XXXIII")
					if preRome == 34:
						print ("The answer is XXXIV")
					if preRome == 35:
						print ("The answer is XXXV")
					if preRome == 36:
						print ("The answer is XXXVI")
					if preRome == 37:
						print ("The answer is XXXVII")
					if preRome == 38:
						print ("The answer is XXXVIII")
					if preRome == 39:
						print ("The answer is XXXVIX")
					if preRome == 40:
						print ("The answer is XL")
					if preRome == 41:
						print ("The answer is XLI")
					if preRome == 42:
						print ("The answer is XLII")
					if preRome == 43:
						print ("The answer is XLIII")
					if preRome == 44:
						print ("The answer is XLIV")
					if preRome == 45:
						print ("The answer is XLV")
					if preRome == 46:
						print ("The answer is XLVI")
					if preRome == 47:
						print ("The answer is XLVII")
					if preRome == 48:
						print ("The answer is XLVIII")
					if preRome == 49:
						print ("The answer is XLVIX")
					if preRome == 50:
						print ("The answer is L")
					if preRome == 51:
						print ("The answer is LI")
					if preRome == 52:
						print ("The answer is LII")
					if preRome == 53:
						print ("The answer is LIII")
					if preRome == 54:
						print ("The answer is LIV")
					if preRome == 55:
						print ("The answer is LV")
					if preRome == 56:
						print ("The answer is LVI")
					if preRome == 57:
						print ("The answer is LVII")
					if preRome == 58:
						print ("The answer is LVIII")
					if preRome == 59:
						print ("The answer is LVIX")
					if preRome == 60:
						print ("The answer is LX")
					if preRome == 61:
						print ("The answer is LXI")
					if preRome == 62:
						print ("The answer is LXII")
					if preRome == 63:
						print ("The answer is LXIII")
					if preRome == 64:
						print ("The answer is LXIV")
					if preRome == 65:
						print ("The answer is LXV")
					if preRome == 66:
						print ("The answer is LXVI")
					if preRome == 67:
						print ("The answer is LXVII")
					if preRome == 68:
						print ("The answer is LXVIII")
					if preRome == 69:
						print ("The answer is LXVIX")
					if preRome == 70:
						print ("The answer is LXX")
					if preRome == 71:
						print ("The answer is LXXI")
					if preRome == 72:
						print ("The answer is LXXII")
					if preRome == 73:
						print ("The answer is LXXIII")
					if preRome == 74:
						print ("The answer is LXXIV")
					if preRome == 75:
						print ("The answer is LXXV")
					if preRome == 76:
						print ("The answer is LXXVI")
					if preRome == 77:
						print ("The answer is LXXVII")
					if preRome == 78:
						print ("The answer is LXXVIII")
					if preRome == 79:
						print ("The answer is LXXVIX")
					if preRome == 80:
						print ("The answer is LXXX")
					if preRome == 81:
						print ("The answer is LXXXI")
					if preRome == 82:
						print ("The answer is LXXXII")
					if preRome == 83:
						print ("The answer is LXXXIII")
					if preRome == 84:
						print ("The answer is LXXXIV")
					if preRome == 85:
						print ("The answer is LXXXV")
					if preRome == 86:
						print ("The answer is LXXXVI")
					if preRome == 87:
						print ("The answer is LXXXVII")
					if preRome == 88:
						print ("The answer is LXXXVIII")
					if preRome == 89:
						print ("The answer is LXXXVIX")
					if preRome == 90:
						print ("The answer is XC")
					if preRome == 91:
						print ("The answer is XCI")
					if preRome == 92:
						print ("The answer is XCII")
					if preRome == 93:
						print ("The answer is XCIII")
					if preRome == 94:
						print ("The answer is XCIV")
					if preRome == 95:
						print ("The answer is XCV")
					if preRome == 96:
						print ("The answer is XCVI")
					if preRome == 97:
						print ("The answer is XCVII")
					if preRome == 98:
						print ("The answer is XCVIII")
					if preRome == 99:
						print ("The answer is XCVIX")
					if preRome == 100:
						print ("The answer is C")
					if preRome == 101:
						print ("The answer is CI") # continue here
					if preRome == 102:
						print ("The answer is CII") 
					if preRome == 103:
						print ("The answer is CIII")
					if preRome == 104:
						print ("The answer is CIV")
					if preRome == 105:
						print ("The answer is CV")
					if preRome == 106:
						print ("The answer is CVI")
					if preRome == 107:
						print ("The answer is CVII")
					if preRome == 108:
						print ("The answer is CVIII")
					if preRome == 109:
						print ("The answer is CVIX")
					if preRome == 110:
						print ("The answer is CX")
					if preRome == 111:
						print ("The answer is CXI")
					if preRome == 112:
						print ("The answer is CXII")
					if preRome == 113:
						print ("The answer is CXIII")
					if preRome == 114:
						print ("The answer is CXIV")
					if preRome == 115:
						print ("The answer is CXV")
					if preRome == 116:
						print ("The answer is CXVI")
					if preRome == 117:
						print ("The answer is CXVII")
					if preRome == 118:
						print ("The answer is CXVIII")
					if preRome == 119:
						print ("The answer is CXIX")
					if preRome == 120:
						print ("The answer is CXX")
					if preRome == 121:
						print ("The answer is CXXI")
					if preRome == 122:
						print ("The answer is CXXII")
					if preRome == 123:
						print ("The answer is CXXIII")
					if preRome == 124:
						print ("The answer is CXXIV")
					if preRome == 125:
						print ("The answer is CXXV")
					if preRome == 126:
						print ("The answer is CXXVI")
					if preRome == 127:
						print ("The answer is CXXVII")
					if preRome == 128:
						print ("The answer is CXXVIII")
					if preRome == 129:
						print ("The answer is CXXIX")
					if preRome == 130:
						print ("The answer is CXXX")
					if preRome == 131:
						print ("The answer is CXXXI")
					if preRome == 132:
						print ("The answer is CXXXII")
					if preRome == 133:
						print ("The answer is CXXXIII")
					if preRome == 134:
						print ("The answer is CXXXIV")
					if preRome == 135:
						print ("The answer is CXXXV")
					if preRome == 136:
						print ("The answer is CXXXVI")
					if preRome == 137:
						print ("The answer is CXXXVII")
					if preRome == 138:
						print ("The answer is CXXXVIII")
					if preRome == 139:
						print ("The answer is CXXXIX")
					if preRome == 140:
						print ("The answer is CXL")
					if preRome == 141:
						print ("The answer is CXLI")
					if preRome == 142:
						print ("The answer is CXLII")
					if preRome == 143:
						print ("The answer is CXLIII")
					if preRome == 144:
						print ("The answer is CXLIV")
					if preRome == 145:
						print ("The answer is CXLV")
					if preRome == 146:
						print ("The answer is CXLVI")
					if preRome == 147:
						print ("The answer is CXLVII")
					if preRome == 148:
						print ("The answer is CXLVIII")
					if preRome == 149:
						print ("The answer is CXLVIX")
					if preRome == 150:
						print ("The answer is CL")
					if preRome == 151:
						print ("The answer is CLI")
					if preRome == 152:
						print ("The answer is CLII")
					if preRome == 153:
						print ("The answer is CLIII")
					if preRome == 154:
						print ("The answer is CLIV")
					if preRome == 155:
						print ("The answer is CLV")
					if preRome == 156:
						print ("The answer is CLVI")
					if preRome == 157:
						print ("The answer is CLVII")
					if preRome == 158:
						print ("The answer is CLVIII")
					if preRome == 159:
						print ("The answer is CLVIX")
					if preRome == 160:
						print ("The answer is CLX")
					if preRome == 161:
						print ("The answer is CLXI")
					if preRome == 162:
						print ("The answer is CLXII")
					if preRome == 163:
						print ("The answer is CLXIII")
					if preRome == 164:
						print ("The answer is CLXIV")
					if preRome == 165:
						print ("The answer is CLXV")
					if preRome == 166:
						print ("The answer is CLXVI")
					if preRome == 167:
						print ("The answer is CLXVII")
					if preRome == 168:
						print ("The answer is CLXVIII")
					if preRome == 169:
						print ("The answer is CLXIX")
					if preRome == 170:
						print ("The answer is CLXX")
					if preRome == 171:
						print ("The answer is CLXXI")
					if preRome == 172:
						print ("The answer is CLXXII")
					if preRome == 173:
						print ("The answer is CLXXIII")
					if preRome == 174:
						print ("The answer is CLXXIV")
					if preRome == 175:
						print ("The answer is CLXXV")
					if preRome == 176:
						print ("The answer is CLXXVI")
					if preRome == 177:
						print ("The answer is CLXXVII")
					if preRome == 178:
						print ("The answer is CLXXVIII")
					if preRome == 179:
						print ("The answer is CLXXIX")
					if preRome == 180:
						print ("The answer is CLXXX")
					if preRome == 181:
						print ("The answer is CLXXXI")
					if preRome == 182:
						print ("The answer is CLXXXII")
					if preRome == 183:
						print ("The answer is CLXXXIII")
					if preRome == 184:
						print ("The answer is CLXXXIV")
					if preRome == 185:
						print ("The answer is CLXXXV")
					if preRome == 186:
						print ("The answer is CLXXXVI")
					if preRome == 187:
						print ("The answer is CLXXXVII")
					if preRome == 188:
						print ("The answer is CLXXXVIII")
					if preRome == 189:
						print ("The answer is CLXXXVIX")
					if preRome == 190:
						print ("The answer is CXC")
					if preRome == 191:
						print ("The answer is CXCI")
					if preRome == 192:
						print ("The answer is CXCII")
					if preRome == 193:
						print ("The answer is CXCIII")
					if preRome == 194:
						print ("The answer is CXCIV")
					if preRome == 195:
						print ("The answer is CXCV")
					if preRome == 196:
						print ("The answer is CXCVI")
					if preRome == 197:
						print ("The answer is CXCVII")
					if preRome == 198:
						print ("The answer is CXCVIII")
					if preRome == 199:
						print ("The answer is CXCVIX")
					if preRome == 200:
						print ("The answer is CC")
					if preRome == 201:
						print ("The answer is CCI")
					if preRome == 202:
						print ("The answer is CCII")
					if preRome == 203:
						print ("The answer is CCIII")
					if preRome == 204:
						print ("The answer is CCIV")
					if preRome == 205:
						print ("The answer is CCV")
					if preRome == 206:
						print ("The answer is CCVI")
					if preRome == 207:
						print ("The answer is CCVII")
					if preRome == 208:
						print ("The answer is CCVIII")
					if preRome == 209:
						print ("The answer is CCVIX")
					if preRome == 210:
						print ("The answer is CCX")
					if preRome == 211:
						print ("The answer is CCXI")
					if preRome == 212:
						print ("The answer is CCXII")
					if preRome == 213:
						print ("The answer is CCXIII")
					if preRome == 214:
						print ("The answer is CCXIV")
					if preRome == 215:
						print ("The answer is CCXV")
					if preRome == 216:
						print ("The answer is CCXVI")
					if preRome == 217:
						print ("The answer is CCXVII")
					if preRome == 218:
						print ("The answer is CCXVIII")
					if preRome == 219:
						print ("The answer is CCXVIX")
					if preRome == 220:
						print ("The answer is CCXX")
					if preRome == 221:
						print ("The answer is CCXXI")
					if preRome == 222:
						print ("The answer is CCXXII")
					if preRome == 223:
						print ("The answer is CCXXIII")
					if preRome == 224:
						print ("The answer is CCXXIV")
					if preRome == 225:
						print ("The answer is CCXXV")
					if preRome == 226:
						print ("The answer is CCXXVI")
					if preRome == 227:
						print ("The answer is CCXXVII")
					if preRome == 228:
						print ("The answer is CCXXVIII")
					if preRome == 229:
						print ("The answer is CCXXVIX")
					if preRome == 230:
						print ("The answer is CCXXX")
					if preRome == 231:
						print ("The answer is CCXXXI")
					if preRome == 232:
						print ("The answer is CCXXXII")
					if preRome == 233:
						print ("The answer is CCXXXIII")
					if preRome == 234:
						print ("The answer is CCXXXIV")
					if preRome == 235:
						print ("The answer is CCXXXV")
					if preRome == 236:
						print ("The answer is CCXXXVI")
					if preRome == 237:
						print ("The answer is CCXXXVII")
					if preRome == 238:
						print ("The answer is CCXXXVIII")
					if preRome == 239:
						print ("The answer is CCXXXVIX")
					if preRome == 240:
						print ("The answer is CCXL")
					if preRome == 241:
						print ("The answer is CCXLI")
					if preRome == 242:
						print ("The answer is CCXLII")
					if preRome == 243:
						print ("The answer is CCXLIII")
					if preRome == 244:
						print ("The answer is CCXLIV")
					if preRome == 245:
						print ("The answer is CCXLV")
					if preRome == 246:
						print ("The answer is CCXLVI")
					if preRome == 247:
						print ("The answer is CCXLVII")
					if preRome == 248:
						print ("The answer is CCXLVIII")
					if preRome == 249:
						print ("The answer is CCXLVIX")
					if preRome == 250:
						print ("The answer is CCL")
					if preRome == 251:
						print ("The answer is CCLI")
					if preRome == 252:
						print ("The answer is CCLII")
					if preRome == 253:
						print ("The answer is CCLIII")
					if preRome == 254:
						print ("The answer is CCLIV")
					if preRome == 255:
						print ("The answer is CCLV")
					if preRome > 255:
						print ("Syntax error! The number you entered is too large for an 8 bit value")
					fallOfTheRomanNumeral = input("Press [ENTER] key to exit")