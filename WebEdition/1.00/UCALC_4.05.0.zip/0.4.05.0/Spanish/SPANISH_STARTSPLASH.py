f lansupportint == 2: 
	class ansi: 
			aa = '\01'
			ab = '\02'
			ac = '\03'
			ad = '\04'
			ae = '\05'
			af = '\06'
			ag = '\07'
			ah = '\08'
			ai = '\09'
			aj = '\10'
			ak = '\11'
			al = '\12'
			am = '\13'
			an = '\14'
			ao = '\15'
			ap = '\16'
			aq = '\17'
			ar = '\18'
			as1 = '\19'
			at = '\20'
			au = '\21'
			av = '\22'
			aw = '\23'
			ax = '\24'
			ay = '\25'
			az = '\26'
			ba = '\27'
			bb = '\28'
			bc = '\29'
			bd = '\30'
			be = '\31'
			bf = '\32'
			bg = '\33'
			bh = '\34'
			bi = '\35'
			bj = '\36'
			bk = '\37'
			bl = '\38'
			bm = '\39'
			bn = '\40'
			bo = '\41'
			bp = '\42'
			bq = '\43'
			br = '\44'
			bs = '\45'
			bt = '\46'
			bu = '\47'
			bv = '\48'
			bw = '\49'
			bx = '\50'
			by = '\51'
			bz = '\52'
			ca = '\53'
			cb = '\54'
			cc = '\55'
			cd = '\56'
			ce = '\57'
			cf = '\58'
			cg = '\59'
			ch = '\60'
			ci = '\61'
			cj = '\62'
			ck = '\63'
			cl = '\64'
			cm = '\65'
			cn = '\66'
			co = '\67'
			cp = '\68'
			cq = '\69'
			cr = '\70'
			cs = '\71'
			ct = '\72'
			cu = '\73'
			cv = '\74'
			cw = '\75'
			cx = '\76'
			cy = '\77'
			cz = '\78'
			da = '\79'
			db = '\80'
			dc = '\81'
			dd = '\82'
			de = '\83'
			df = '\84'
			dg = '\85'
			dh = '\86'
			di = '\87'
			dj = '\88'
			dk = '\89'
			dl = '\90'
	# more1 = input("1 to 26")
	'''
	print (ansi.aa)
	print (ansi.ab)
	print (ansi.ac)
	print (ansi.ad)
	print (ansi.ae)
	print (ansi.af)
	print (ansi.ag)
	print (ansi.ah)
	print (ansi.ai)
	print (ansi.aj)
	print (ansi.ak)
	print (ansi.al)
	print (ansi.am)
	print (ansi.an)
	print (ansi.ao)
	print (ansi.ap)
	print (ansi.aq)
	print (ansi.ar)
	print (ansi.as1)
	print (ansi.at)
	print (ansi.au)
	print (ansi.av)
	print (ansi.aw)
	print (ansi.ax)
	print (ansi.ay)
	print (ansi.az)
	print (ansi.ba)
	'''
	# more1 = input("27 to 52")
	'''
	print (ansi.bb)
	print (ansi.bc)
	print (ansi.bd)
	print (ansi.be)
	print (ansi.bf)
	print (ansi.bg)
	print (ansi.bh)
	print (ansi.bi)
	print (ansi.bj)
	print (ansi.bk)
	print (ansi.bl)
	print (ansi.bm)
	print (ansi.bn)
	print (ansi.bo)
	print (ansi.bp)
	print (ansi.bq)
	print (ansi.br)
	print (ansi.bs)
	print (ansi.bt)
	print (ansi.bu)
	print (ansi.bv)
	print (ansi.bw)
	print (ansi.bx)
	print (ansi.by)
	print (ansi.bz)
	'''
	# more1 = input("53 to 78")
	'''
	print (ansi.ca)
	print (ansi.cb)
	print (ansi.cc)
	print (ansi.cd)
	print (ansi.ce)
	print (ansi.cf)
	print (ansi.cg)
	print (ansi.ch)
	print (ansi.ci)
	print (ansi.cj)
	print (ansi.ck)
	print (ansi.cl)
	print (ansi.cm)
	print (ansi.cn)
	print (ansi.co)
	print (ansi.cp)
	print (ansi.cq)
	print (ansi.cr)
	print (ansi.cs)
	print (ansi.ct)
	print (ansi.cu)
	print (ansi.cv)
	print (ansi.cw)
	print (ansi.cx)
	print (ansi.cy)
	print (ansi.cz)
	'''
	# more1 = input("79 to 90")
	'''
	print (ansi.da)
	print (ansi.db)
	print (ansi.dc)
	print (ansi.dd)
	print (ansi.de)
	print (ansi.df)
	print (ansi.dg)
	print (ansi.dh)
	print (ansi.di)
	print (ansi.dj)
	print (ansi.dk)
	print (ansi.dl)
	print ("\n\n\nEnd of scale")
	end1 = input("\nPress [ENTER] key to quit")
	print ("Exiting")
	'''
	# model ID
	modID = str("PI-6400x702")
	konlop = int(1)
	adminpas = str("password")
	adminusr = str("admin")
	print ("Calculator mode: " + str(modID) + " \n")
	# boot screen 
	print ("|||||||||||||||||||||||")
	print ("|   U L T I M A T E   |")
	print ("| C A L C U L A T O R |")
	print ("|                     |")
	print ("| A L P H A   3       |")
	print ("|                     |")
	print ("|||||||||||||||||||||||")
	print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
	biospar = input("Press [ENTER] key to start (Enter B3 to enter BIOS)")
	'''
	////
	///
	//
	/
	End of the UCalc System source code!
	\
	\\
	\\\
	\\\\
	'''S