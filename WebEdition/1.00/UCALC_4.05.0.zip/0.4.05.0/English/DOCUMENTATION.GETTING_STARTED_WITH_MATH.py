WikIDSelect = int(30000)
if WikIDSelect == 30000:
	if WikIDSelect == 30000:
		if WikIDSelect == 30000:
			if WikIDSelect == 30000:
				print ("This section is not yet available")
				noMore = input("Press [ENTER] key to exit")
				print ("Exiting")
				print ("Please wait...")