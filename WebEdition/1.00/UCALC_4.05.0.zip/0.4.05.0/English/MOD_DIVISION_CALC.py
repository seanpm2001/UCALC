		if calcIDSes == 11:
					print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
					print ("Modular division")
					modivision1 = int(input("Enter first number to mod: "))
					modivision2 = int(input("Enter second number to mod: "))
					curanswer = (modivision1 % modivision2)
					print ("The remainder of " + str(modivision1) + " and " + str(modivision2) + " is " + str(curanswer))
					bloat1 = input("| FAIL! SETUP RESTARTING (we can't fix the bug right now, we are porting features in. Stabilizing later, my bad)")