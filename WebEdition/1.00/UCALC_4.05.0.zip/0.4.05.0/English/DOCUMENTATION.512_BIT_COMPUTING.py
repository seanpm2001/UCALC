WikIDSelect = int(20018)
if WikIDSelect == 20018:
	if WikIDSelect == 20018:
		if WikIDSelect == 20018:
			if WikIDSelect == 20018:
				print (" ")
				print ("In computer architecture, 512-bit integers, memory addresses, or other data units are those that are 512 bits wide. Also, ")
				print ("512-bit CPU and ALU architectures are those that are based on registers, address buses, or data buses of that size.")
				print (" ")
				print ("There are currently no mainstream general-purpose processors built to operate on 512-bit integers or addresses, though a ")
				print ("number of processors do operate on 512-bit data. As of 2013, the Intel Xeon Phi has a vector processing unit with 512-bit") 
				print ("vector registers, each one holding sixteen 32-bit elements or eight 64-bit elements, and a single instruction can operate on") 
				print ("all these values in parallel. However, the Xeon Phi's vector processing unit does not operate on individual numbers that are ")
				print ("512 bits in length.[1]")
				more1 = input("Uses")
				print ("The AMD Radeon R9 290X (Sapphire OEM version pictured here) uses a 512 bit memory bus")
				print ("PICTURE NOT AVAILABLE IN COMMAND LINE VIEW")
				print ("	Some GPUs such as the Nvidia GTX280,[2] GTX285,[3] Quadro FX 5800[4] and several Tesla products move data across a 512-bit") 
				print ("	memory bus. Then AMD Radeon R9 290, R9 290X and 295X2 followed.")
				print ("	Many hash functions, such as SHA-512, have a 512-bit output.")
				print ("	AVX-512 are 512-bit extensions to the 256-bit Advanced Vector Extensions SIMD instructions for x86 instruction set ")
				print ("	architecture proposed by Intel in July 2013, and released on 2016 with Knights Landing, and in 2018 on the HEDT and ")
				print ("	consumer server platform, with Skylake-X and Skylake-SP respectively.")
				noMore = input("Press [ENTER] key to exit")