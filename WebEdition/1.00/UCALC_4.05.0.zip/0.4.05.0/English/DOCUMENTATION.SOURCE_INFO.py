WikIDSelect = int(10003)
if WikIDSelect == 10003:
	if WikIDSelect == 10003:
		if WikIDSelect == 10003:
			if WikIDSelect == 10003:
				print ("Source info")
				print ("Language: Python 3x (3.0, 3.1, 3.2, 3.3, 3.4, 3.5, 3.6, 3.7, 3.8)")
				print ("Tools used: \nPython 3.6.exe\nNotepad++\nNotepad.exe")
				print ("Lines of code: 3470")
				print ("Bytes: 394393")
				noMore = input("Press [ENTER] key to exit source info")
				print ("Closing")
				print ("Please wait")