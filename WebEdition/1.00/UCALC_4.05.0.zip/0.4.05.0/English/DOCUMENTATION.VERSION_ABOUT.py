WikIDSelect = int(10001)
if WikIDSelect == 10001:
	if WikIDSelect == 10001:
		if WikIDSelect == 10001:
			if WikIDSelect == 10001:
				print ("UCalc Pro")
				print ("Demonstration build")
				print ("Alpha 1")
				print ("Version 0.01")
				print ("Copyleft Sean Walla Walla")
				print ("Written in Python 3")
				noMore = input("Press [ENTER] key to exit version info")
				print ("Exiting version info")
				print ("Please wait...")