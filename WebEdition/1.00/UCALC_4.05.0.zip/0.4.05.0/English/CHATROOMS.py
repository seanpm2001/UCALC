		if selectACessory == ("2"):
			print ("Chatrooms")
			print ("\n")
			print ("|=====================|")
			print ("| Join a room [ID: 1] |")
			print ("|=====================|")
			print ("\n")
			print ("|===========================|")
			print ("| Create a new room [ID: 2] |")
			print ("|===========================|")
			print ("\n\n\n\n\n\n")
			roomJoiner = str(input("Enter the ID to join or create a room: "))
			if roomJoiner == ("1"):
				print ("No rooms found!")
			if roomJoiner == ("2"):
				print ("New room")
	exit1 = input("Press [ENTER] key to exit")