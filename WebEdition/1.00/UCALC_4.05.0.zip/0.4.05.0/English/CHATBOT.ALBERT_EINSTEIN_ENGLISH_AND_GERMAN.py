chatID = int(4)
if (chatID == 4):
	print ("You are now talking with Albert Einstein")
	print ("|--------|")
	print ("This is the start of our conversation! Try to say a greeting")
	print ("Albert Einstein > Hello there! ")
	loopforever3 = int(1)
	while (loopforever3 == 1):
		console1 = str(input("You > "))
		if (console1 == "happy man" or console1 == "Happy man" or console1 == "Happy Man" or console1 == "HAPPY MAN"):
			print ("Albert Einstein > Un homme heureux est trop content du présent pour trop se soucier de l'avenir.")
			print ("\n{Translation} A happy man is too satisfied with the present to dwell too much on the future.")
		if (console1 == "authority" or console1 == "Authority" or console1 == "AUTHORITY"):
			print ("Albert Einstein > Autoritätsdusel ist der größte Feind der Wahrheit.")
			print ("\n{Translation} Unthinking respect for authority is the greatest enemy of truth.")
		if (console1 == "enemy" or console1 == "Enemy" or console1 == "ENEMY"):
			print ("Albert Einstein > Lieber Habicht! / Es herrscht ein weihevolles Stillschweigen zwischen uns, so daß es mir fast wie eine sündige Entweihung vorkommt, ")
			print ("wenn ich es jetzt durch ein wenig bedeutsames Gepappel unterbreche... / Was machen Sie denn, Sie eingefrorener Walfisch, Sie getrocknetes, eingebüchstes")
			print ("Stück Seele...?")
			print ("\n{Translation} Dear Habicht, / Such a solemn air of silence has descended between us that I almost feel as if I am committing a sacrilege when I break")
			print ("it now with some inconsequential babble... / What are you up to, you frozen whale, you smoked, dried, canned piece of soul...?")
		if (console1 == "body" or console1 == "Body" or console1 == "BODY"):
			print ("Albert Einstein > Ist die Trägheit eines Körpers von seinem Energieinhalt abhängig? ")
			print ("\n{Translation} Does the inertia of a body depend upon its energy content?")
		if (console1 == "lion" or console1 == "Lion" or console1 == "LION"):
			print ("Albert Einstein > Die Natur zeigt uns vom Löwen zwar nur den Schwanz. Aber es ist mir unzweifelhaft, dass der Löwe dazugehört, wenn er sich auch wegen ")
			print ("seiner ungeheuren Dimensionen dem Blicke nicht unmittelbar offenbaren kann. Wir sehen ihn nur wie eine Laus, die auf ihm sitzt.")
			print ("\n{Translation} Nature shows us only the tail of the lion. But there is no doubt in my mind that the lion belongs with it even if he cannot reveal ")
			print ("himself to the eye all at once because of his huge dimension. We see him only the way a louse sitting upon him would.")
		if (console1 == "epoch" or console1 == "Epoch" or console1 == "EPOCH"):
			print ("Albert Einstein > Man begreift schwer beim Erleben dieser ''großen Zeit'', daß man dieser verrückten, verkommenen Spezies angehört, die sich ")
			print ("Willensfreiheit zuschreibt. Wenn es doch irgendwo eine Insel der Wohlwollenden und Besonnenen gäbe! Da wollte ich auch glühender Patriot sein.")
			print ("\n{Translation} In living through this ''great epoch,'' it is difficult to reconcile oneself to the fact that one belongs to that mad, degenerate ")
			print ("species that boasts of its free will. How I wish that somewhere there existed an island for those who are wise and of good will! In such a place even ")
			print ("I should be an ardent patriot!")
		if (console1 == "retract" or console1 == "Retract" or console1 == "RETRACT"):
			print ("Albert Einstein > Es ist bequem mit dem Einstein. Jedes Jahr widerruft er, was er das vorige Jahr geschrieben hat.")
			print ("\n{Translation} It's convenient with that fellow Einstein, every year he retracts what he wrote the year before.")
		if (console1 == "game" or console1 == "Game" or console1 == "GAME" or console1 == "idle" or console1 == "Idle" or console1 == "IDLE" or console1 == "idle game" or console1 == "Idle game" or console1 == "Idle Game" or console1 == "idle Game" or console1 == "IDLE game" or console1 == "IDLE Game" or console1 == "IDLE GAME"):
			print ("Albert Einstein > Begriffe, welche sich bei der Ordnung der Dinge als nützlich erwiesen haben, erlangen über uns leicht eine solche Autorität, ")
			print ("dass wir ihres irdischen Ursprungs vergessen und sie als unabänderliche Gegebenheiten hinnehmen.] Thus they might come to be stamped as ")
			print ("''necessities of thought,'' ''a priori givens,'' etc. The path of scientific progress is often made impassable for a long time by such errors. ")
			print ("[Der Weg des wissenschaftlichen Fortschritts wird durch solche Irrtümer oft für längere Zeit ungangbar gemacht.")
			print ("\n{Translation} Therefore it is by no means an idle game if we become practiced in analysing long-held commonplace concepts and showing the ")
			print ("circumstances on which their justification and usefulness depend, and how they have grown up, individually, out of the givens of experience. ")
			print ("Thus their excessive authority will be broken. They will be removed if they cannot be properly legitimated, corrected if their correlation with") 
			print ("given things be far too superfluous, or replaced if a new system can be established that we prefer for whatever reason. ")
		if (console1 == "technology" or console1 == "Technology" or console1 == "TECHNOLOGY"):
			print ("Albert Einstein > Unser ganzer gepriesener Fortschritt der Technik, überhaupt die Civilisation, ist der Axt in der Hand des pathologischen ")
			print ("Verbrechers vergleichbar.")
			print ("\n{Translation} Our entire much-praised technological progress, and civilization generally, could be compared to an axe in the hand of a ")
			print ("pathological criminal.")
		if (console1 == "pram" or console1 == "Pram" or console1 == "PRAM"):
			print ("Albert Einstein > Ich habe auch manchen wissenschaftlichen Plan überlegt, während ich Dich im Kinderwagen spazieren schob!")
			print ("\n{Translation} I have also considered many scientific plans during my pushing you around in your pram!")
		if (console1 == "grow up" or console1 == "Grow up" or console1 == "Grow Up" or console1 == "GROW UP" or console1 == "healthy" or console1 == "Healthy" or console1 == "HEALTHY"):
			print ("Albert Einstein > Geh recht viel spazieren, dass Du recht gesund wirst und lies nicht gar zu viel sondern spar Dir noch was auf bis Du gross bist.")
			print ("\n{Translation} Make a lot of walks to get healthy and don’t read that much but save yourself some until you’re grown up.")
		if (console1 == "mom" or console1 == "Mom" or console1 == "MoM" or console1 == "MOM" or console1 == "mother" or console1 == "Mother" or console1 == "MOTHER"):
			print ("Albert Einstein > Liebe Mutter! Heute eine freudige Nachricht. H. A. Lorentz hat mir telegraphiert, dass die englischen Expeditionen die ")
			print ("Lichtablenkung an der Sonne wirklich bewiesen haben.")
			print ("\n{Translation} Dear mother! Today a joyful notice. H. A. Lorentz has telegraphed me that the English expeditions have really proven the deflection ")
			print ("of light at the sun.")
		if (console1 == "jew" or console1 == "Jew" or console1 == "JEW" or console1 == "jewish" or console1 == "Jewish" or console1 == "JEWISH" or console1 == "swiss jew" or console1 == "Swiss jew" or console1 == "Swiss Jew" or console1 == "SWISS JEW"):
			print ("Albert Einstein > Noch eine Art Anwendung des Relativitätsprinzips zum Ergötzen des Lesers: Heute werde ich in Deutschland als ")
			print ("''deutscher Gelehrter'', in England als ''Schweizer Jude'' bezeichnet; sollte ich aber einst in die Lage kommen, als ''bète noire'' ")
			print ("präsentiert zu werden, dann wäre ich umgekehrt für die Deutschen ein Schweizer Jude'', für die Engländer ein ''deutscher Gelehrter''.")
			print ("\n{Translation} By an application of the theory of relativity to the taste of readers, today in Germany I am called a German man of ")
			print ("science, and in England I am represented as a Swiss Jew. If I come to be represented as a bête noire, the descriptions will be reversed, ")
			print ("and I shall become a Swiss Jew for the Germans and a German man of science for the English!")
		if (console1 == "" or console1 == " " or console1 == "  " or console1 == "   "):
			print ("Albert Einstein > Please type something! Don't leave it blank")
		else:
			print ("Albert Einstein > I am not sure what you said. Please check your syntax and try again!")