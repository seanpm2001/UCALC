print (" ")
print (" ")
print (" ")
print (" ____  __    ___  ____  _____  ____  ____    __    __            ")
print ("( ___)/__\\  / __)(_  _)(  _  )(  _ \\(_  _)  /__\\  (  )           ")
print (" )__)/(__)\\( (__   )(   )(_)(  )   / _)(_  /(__)\\  )(__          ")
print ("(__)(__)(__)\\___) (__) (_____)(_)\\_)(____)(__)(__)(____)         ")
print ("  ___    __    __    ___  __  __  __      __   ____  _____  ____ ")
print (" / __)  /__\\  (  )  / __)(  )(  )(  )    /__\\ (_  _)(  _  )(  _ \\")
print ("( (__  /(__)\\  )(__( (__  )(__)(  )(__  /(__)\\  )(   )(_)(  )   /")
print (" \\___)(__)(__)(____)\\___)(______)(____)(__)(__)(__) (_____)(_)\\_)")
print (" ")
print (" ")
enterToEnter = input("Press [ENTER] key to start!")
calcIDSes = int(58)
if calcIDSes == 58:
	print ("Factorial calculator")
	print ("(!) This program is locked in 5x64 mode. Numbers you input must be within a 5 bit value (1-64) but the factorial that outputs is 64 bit")
	enterAFactorial = str(input("Enter a number (1-64) to start: "))
	if (enterAFactorial == "1"):
		print ("The factorial of 1 is 1")
	if (enterAFactorial == "2"):
		print ("The factorial of 2 is 2")
	if (enterAFactorial == "3"):
		print ("The factorial of 3 is 6")
	if (enterAFactorial == "4"):
		print ("The factorial of 4 is 24")
	if (enterAFactorial == "5"):
		print ("The factorial of 5 is 120")
	if (enterAFactorial == "6"):
		print ("The factorial of 6 is 720")	
	if (enterAFactorial == "7"):
		print ("The factorial of 7 is 6040")	
	if (enterAFactorial == "8"):
		print ("The factorial of 8 is 40320")
	if (enterAFactorial == "9"):
		print ("The factorial of 9 is 362880")
	if (enterAFactorial == "10"):
		print ("The factorial of 10 is 3628800")	
	if (enterAFactorial == "11"):
		print ("The factorial of 11 is 39916800")		
	if (enterAFactorial == "12"):
		print ("The factorial of 12 is 479001600")	
	if (enterAFactorial == "13"):
		print ("The factorial of 13 is 6227020800")	
	if (enterAFactorial == "14"):
		print ("The factorial of 14	is 87178291200")	
	if (enterAFactorial == "15"):
		print ("The factorial of 15 is 1.3076744e+12")
	if (enterAFactorial == "16"):
		print ("The factorial of 16 is 2.092279e+13")	
	if (enterAFactorial == "17"):
		print ("The factorial of 17 is 3.5568743e+14")	
	if (enterAFactorial == "18"):
		print ("The factorial of 18 is 6.4023737e+15")	
	if (enterAFactorial == "19"):
		print ("The factorial of 19 is 1.216451e+17")	
	if (enterAFactorial == "20"):
		print ("The factorial of 20 is 2.432902e+18")	
	if (enterAFactorial == "21"):
		print ("The factorial of 21 is 5.1090942e+19")
	if (enterAFactorial == "22"):
		print ("The factorial of 22 is 1.1240007e+21")	
	if (enterAFactorial == "23"):
		print ("The factorial of 23 is 2.5852017e+22")
	if (enterAFactorial == "24"):
		print ("The factorial of 24 is 6.204484e+23")
	if (enterAFactorial == "25"):
		print ("The factorial of 25 is 1.551121e+25")
	if (enterAFactorial == "26"):
		print ("The factorial of 26 is 4.0329146e+26")
	if (enterAFactorial == "27"):
		print ("The factorial of 27 is 1.0888869e+28")
	if (enterAFactorial == "28"):
		print ("The factorial of 28 is 3.0488834e+29")
	if (enterAFactorial == "29"):
		print ("The factorial of 29 is 8.841762e+30")
	if (enterAFactorial == "30"):
		print ("The factorial of 30 is 2.6525286e+32")
	if (enterAFactorial == "31"):
		print ("The factorial of 31 is 8.2228387e+33")
	if (enterAFactorial == "32"):
		print ("The factorial of 32 is 8.2228387e+33")
	if (enterAFactorial == "33"):
		print ("The factorial of 33 is 2.952328e+38")
	if (enterAFactorial == "34"):
		print ("The factorial of 34 is 2.952328e+38")
	if (enterAFactorial == "35"):
		print ("The factorial of 35 is 1.0333148e+40")
	if (enterAFactorial == "36"):
		print ("The factorial of 36 is 3.7199333e+41")
	if (enterAFactorial == "37"):
		print ("The factorial of 37 is 1.3763753e+43")
	if (enterAFactorial == "38"):
		print ("The factorial of 38 is 5.2302262e+44")
	if (enterAFactorial == "39"):
		print ("The factorial of 39 is 2.0397882e+46")
	if (enterAFactorial == "40"):
		print ("The factorial of 40 is 8.1591528e+47")	
	if (enterAFactorial == "41"):
		print ("The factorial of 41 is 3.3452527e+49")
	if (enterAFactorial == "42"):
		print ("The factorial of 42 is 1.4050061e+51")
	if (enterAFactorial == "43"):
		print ("The factorial of 43 is 6.0415263e+52")
	if (enterAFactorial == "44"):
		print ("The factorial of 44 is 2.6582716e+54")
	if (enterAFactorial == "45"):
		print ("The factorial of 45 is 1.1962222e+56")
	if (enterAFactorial == "46"):
		print ("The factorial of 46 is 5.5026222e+57")
	if (enterAFactorial == "47"):
		print ("The factorial of 47 is 2.5862324e+59 ")
	if (enterAFactorial == "48"):
		print ("The factorial of 48 is 1.2413916e+61")
	if (enterAFactorial == "49"):
		print ("The factorial of 49 is 6.0828186e+62")
	if (enterAFactorial == "50"):
		print ("The factorial of 50 is 3.0414093e+64")
	if (enterAFactorial == "51"):
		print ("The factorial of 51 is 1.5511188e+66")
	if (enterAFactorial == "52"):
		print ("The factorial of 52 is 8.0658175e+67 ")
	if (enterAFactorial == "53"):
		print ("The factorial of 53 is 4.2748833e+69 ")
	if (enterAFactorial == "54"):
		print ("The factorial of 54 is 2.308437e+71")	
	if (enterAFactorial == "55"):
		print ("The factorial of 55 is 1.2696403e+73")
	if (enterAFactorial == "56"):
		print ("The factorial of 56 is 1099859e+74")
	if (enterAFactorial == "57"):
		print ("The factorial of 57 is 4.052692e+76")
	if (enterAFactorial == "58"):
		print ("The factorial of 58 is 2.3505613e+78")
	if (enterAFactorial == "59"):
		print ("The factorial of 59 is 1.3868312e+80")
	if (enterAFactorial == "60"):
		print ("The factorial of 60 is 8.3209871e+81")
	if (enterAFactorial == "61"):
		print ("The factorial of 61 is 5.0758021e+83")
	if (enterAFactorial == "62"):
		print ("The factorial of 62 is 3.1469973e+85")
	if (enterAFactorial == "63"):
		print ("The factorial of 63 is 1.9826083e+87")
	if (enterAFactorial == "64"):
		print ("The factorial of 64 is 1.2688693e+89")		
	else:
		print ("The number you entered is not a valid 5 bit number. Failed to translate to a factorial")
noMore = input("Press [ENTER] key to quit")
'''
Factorial

1 factorial = 1
2 factorial = 2
3 factorial = 6
4 factorial = 24
5 factorial = 120
6 factorial = 720
7 factorial = 5040
8 factorial = 40320
9 factorial = 362880
10 factorial = 3628800
11 factorial = 39916800
12 factorial = 479001600 (479,001,600)
13 factorial = 6227020800 (6,227,020,800)
14 factorial = 87178291200 (87,178,291,200)
15 factorial = 1.3076744e+12
16 factorial = 2.092279e+13
17 factorial = 3.5568743e+14
18 factorial = 6.4023737e+15
19 factorial = 1.216451e+17
20 factorial = 2.432902e+18
21 factorial = 5.1090942e+19
22 factorial = 1.1240007e+21
23 factorial = 2.5852017e+22
24 factorial = 6.204484e+23
25 factorial = 1.551121e+25
26 factorial = 4.0329146e+26
27 factorial = 1.0888869e+28
28 factorial = 3.0488834e+29
29 factorial = 8.841762e+30
30 factorial = 2.6525286e+32
31 factorial = 8.2228387e+33
32 factorial = 2.6313084e+35
33 factorial = 8.6833176e+36
34 factorial = 2.952328e+38
35 factorial = 1.0333148e+40
36 factorial = 3.7199333e+41
37 factorial = 1.3763753e+43
38 factorial = 5.2302262e+44
39 factorial = 2.0397882e+46
40 factorial = 8.1591528e+47
41 factorial = 3.3452527e+49
42 factorial = 1.4050061e+51
43 factorial = 6.0415263e+52
44 factorial = 2.6582716e+54
45 factorial = 1.1962222e+56
46 factorial = 5.5026222e+57
47 factorial = 2.5862324e+59 
48 factorial = 1.2413916e+61
49 factorial = 6.0828186e+62
50 factorial = 3.0414093e+64
51 factorial = 1.5511188e+66
52 factorial = 8.0658175e+67 
53 factorial = 4.2748833e+69 
54 factorial = 2.308437e+71
55 factorial = 1.2696403e+73
56 factorial = 7.1099859e+74
57 factorial = 4.052692e+76
58 factorial = 2.3505613e+78
59 factorial = 1.3868312e+80   
60 factorial = 8.3209871e+81
61 factorial = 5.0758021e+83
62 factorial = 3.1469973e+85
63 factorial = 1.9826083e+87
64 factorial = 1.2688693e+89
'''
# end of program script 