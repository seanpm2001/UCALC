		if calcIDSes == 51:
					print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
					print ("Random Number Generator (with decimals)")
					ranrange = float(input("How many random numbers do you want to generate (1-100 MAX recommended): "))
					rand1 = float(input("Enter the start number of the random range: "))
					rand2 = float(input("Enter the end number of the random range: "))
					staran = float
					staran == 0.0
					while not (staran == ranrange):
						ranrange - 1.0
						print (random.randint(rand1, rand2))
					bloat1 = input("| FAIL! SETUP RESTARTING (we can't fix the bug right now, we are porting features in. Stabilizing later, my bad)")