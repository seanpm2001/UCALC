		if calcIDSes == 29:
					print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
					print ("Percentage")
					percent1 = float(input("Enter a number to find its percentage"))
					curanswer = (percent1 / 1)
					print (str(percent1) + " is " + str(curanswer) + " percent of 100")
					bloat1 = input("| FAIL! SETUP RESTARTING (we can't fix the bug right now, we are porting features in. Stabilizing later, my bad)")