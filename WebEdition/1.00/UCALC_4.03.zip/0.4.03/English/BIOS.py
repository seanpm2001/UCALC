	if (biospar == "B3"):
		bioloop = int(0)
		print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
		while (bioloop == 0):
			print ("====================================================================================>")
			print ("UCALC System Basic Input Output System")
			print ("Model ID: " + str(modID) + "\t\tLoop ID: " + str(konlop))
			print ("Administrator username: " + str(adminusr) + "\nType 'ADMU' to modify")
			print ("Administrator password: " + str(adminpas) + "\nType 'ADMP' to modify")	
			modibio = str(input("Enter a modification code\nType Q to exit: "))
			if (modibio == "ADMU"):
				print ("Administrator account")
				adminusr = str(input("Rename the administrator: "))
			if (modibio == "ADMP"):
				print ("Administrator password")
				adminpas = str(input("Change the password: "))
			if (modibio == "Q"):
				(bioloop == 1)
				if (bioloop == 1):
					if (bioloop == 1):
						print ("Cannot exit BIOS, Looping Error\nSorry :|")
			print ("Error, unknown command")
			'''
	print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
	print ("Presentation build for:\nMrs. Nelson's pre-algebra class\nAt Walla Walla High School")
	bootpas = input("Press [ENTER] key to start...")
	print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
	'''
	# boot menu
	print ("Ultimate calculator")
	konloop = int(konlop)
	#while konloop == 1: # please do not re-enable konloop unless you are going to fix it
	print ("Copyleft Sean Walla Walla 2015-2018")
	print ("\nReading from UCALC.UCALC_ROM")
	more1 = input("Ready to start!\nPress [ENTER] key to enter the main menu")
	''' pre 3.61 main menu script (1 line removed)
	print ("| My calculators  [ID: 1] |")
	print ("| Setup (old)     [ID: 2] |")
	print ("| Wiki            [ID: 3] |")
	print ("| Exit            [ID: 4] |")
	print ("| Public calc     [ID: 5] |")
	print ("| Games           [ID: 6] |")
	print ("| Explorer        [ID: 7] |")
	print ("| Accessories     [ID: 8] |")
	print ("| Settings        [ID: 9] |")
	print ("|                         |")
	print ("\\                         /")
	print (" \\=======================/")
	print ("  \\ Version 0.01 alpha  /")
	print ("   \\ developer copy    /")
	print ("    \\=================/")
	'''