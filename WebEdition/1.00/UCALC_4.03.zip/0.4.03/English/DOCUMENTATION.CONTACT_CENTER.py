WikIDSelect = int(10011)
if WikIDSelect == 10011:
	if WikIDSelect == 10011:
		if WikIDSelect == 10011:
			if WikIDSelect == 10011:
				print ("Contact Center")
				print ("\nWeb contacts\nWARNING! These links may not be functional in the future")
				print ("YouTube: https://www.youtube.com/c/seanwallawalla")
				print ("Twitter: https://www.twitter.com/seanwallawalla")
				print ("Reddit: https://www.reddit.com/u/seanwallawalla")
				print ("\nMailing\nWARNING! These links may not be functional in the future")
				print ("GMAIL: theironmelonmc4384141@gmail.com")
				print (" ")