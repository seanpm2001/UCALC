WikIDSelect = int(10005)
if WikIDSelect == 10005:
	if WikIDSelect == 10005:
		if WikIDSelect == 10005:
			if WikIDSelect == 10005:
				print ("Manufacturing guide")
				print ("===================")
				print ("Requirements:")
				print ("1280x720 or higher screen (FPS doesn't matter, as long as it is at least 24 FPS)")
				print ("64 bit processor")
				print ("256 Megabytes of RAM")
				print ("1024 Megabytes of disk space")
				print ("8 bit color or more")
				print ("No internet connection required PLEASE keep it this way")
				print ("Battery: at least 1500 mAh capacity (2600 mAh or higher recommended)")
				print ("Keypad:")
				print ("| 1 2 3 4 5 6 7 8 9 0 a b c d e f g h i j k l m n o p q r s t u v w x y z")
				print ("====================================================================================================")