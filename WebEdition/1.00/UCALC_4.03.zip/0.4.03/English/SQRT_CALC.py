		if calcIDSes == 21:
					print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
					print ("Square root")
					sqrtmain1 = int(input("Enter a number to find its square root: "))
					curanswer = (sqrtmain1 * sqrtmain1) 
					print ("The square root of " + str(sqrtmain1) + " is: " + str(curanswer))
					bloat1 = input("| FAIL! SETUP RESTARTING (we can't fix the bug right now, we are porting features in. Stabilizing later, my bad)")