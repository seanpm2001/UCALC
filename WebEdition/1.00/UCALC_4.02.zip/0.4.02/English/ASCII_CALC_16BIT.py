print ("ASCII table")
print ("(!) note: this program is locked in 16 bit mode")
entAscii = int(input("Enter a number (0-65535) to returnits ASII character: "))
entAscii2 = int
entAscii2 == entAscii
while (entAscii == entAscii):
	if (entAscii > 0 and entAscii < 65536):
		print (chr(entAscii) + " " + str(entAscii))
		more1 = input("========")
		entAscii = entAscii + 1
	else:
		print ("Invalid number entered!")
		noMore = input("Press [ENTER] key to quit")
noMore = input("Press [ENTER] key to quit")

