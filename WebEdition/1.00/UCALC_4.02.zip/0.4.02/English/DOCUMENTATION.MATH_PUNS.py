WikIDSelect = int(10008)
if WikIDSelect == 10008:
	if WikIDSelect == 10008:
		if WikIDSelect == 10008:
			if WikIDSelect == 10008:
				print ("Math puns! ")
				print ("\n\n")
				spoilerblock = input("What do you call a snake that is 3.14 meters long?")
				print ("\n\nA python!")
				more1 = input("Press [ENTER] key for more")
				spoilerblock = input("Why is 9 afraid of 7?")
				print ("\n\nBecause 7 8 9")
				more1 = input("Press [ENTER] key for more")
				print ("Sorry we are fresh out of math puns for this version :/")
				noMore = input("Press [ENTER] key to exit")