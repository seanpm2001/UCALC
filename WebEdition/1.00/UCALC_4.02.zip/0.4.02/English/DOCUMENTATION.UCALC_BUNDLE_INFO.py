WikIDSelect = int(10010)
if WikIDSelect == 10010:
	if WikIDSelect == 10010:
		if WikIDSelect == 10010:
			if WikIDSelect == 10010:
				print ("UCalc bundle info")
				print ("50 calculation modes")
				print ("10 games")
				print ("5 screensavers")
				print ("Chatrooms")
				print ("All for $00.00")
				print ("We want this project to continue as a free project, and we need YOUR donations.")
				print ("\nYou can help donate money, but if you are short on cash, you can also donate by helping work with the software, such as")
				print ("Monitoring distros, changing the code, advertising, and more")