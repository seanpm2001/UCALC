		if calcIDSes == 15:
					print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
					print ("Divide")
					divided1 = int(input("Enter first number to divide: "))
					divided2 = int(input("Enter second number to divide: "))
					curanswer = (divided1 / divided2)
					print ("\n\nThe answer is: " + str(curanswer))