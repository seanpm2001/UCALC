					if gameselectID == 11:
						print ("Launch the X")
						print ("\n\n")
						launchx1 = input("Press [ENTER] key to start")
						megalaunch = (1)
						while megalaunch == (1):
							print ("   x   ")
							launchx2 = input("Press [ENTER] to launch the X")
							print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
							print ("All Xcrafts have been launched")
							exit = input("Press [ENTER] key to quit")