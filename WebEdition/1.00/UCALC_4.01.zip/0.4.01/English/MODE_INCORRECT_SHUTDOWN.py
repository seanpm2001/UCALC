	if not uCMainConsole == (1 or 2 or 3 or 4 or 5 or 6 or 7 or 8 or 9 or 10):
		print ("System error")
		print ("Shutting down")
		endSession2 = str(input("Are you sure you want to end your calculating session? (Y/N)"))
		print ("Ending session")