					if gameselectID == 10:
						print ("\n\n\n\n\n\n\n\n")
						print ("Welcome to 2048!")
						print ("Multiples of 2:")
						print ("2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 9192, 16384, 32768, x+")
						print ("ERROR! This game is not available in the Command Line version. Please use the Graphical mode to play this game")
						print ("ERROR! (2) This game is not yet developed. Please use a newer version to continue")
						endgame1 = input("Exiting game, press [ENTER] key to continue")