		if calcIDSes == 28:
					print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
					print ("Years between")
					print ("This mode is currently unavailable. Sorry for the inconvenience ")
					print ("We are still working on adding in new features and stabilizing the program. Please install a newer version to calculate the years between a date")
					print ("No error, just not here yet")
					bloat1 = input("| FAIL! SETUP RESTARTING (we can't fix the bug right now, we are porting features in. Stabilizing later, my bad)")